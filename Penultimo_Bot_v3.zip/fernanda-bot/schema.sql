-- ============================================================
-- SCHEMA — Bot Fernanda / Crescendo com a Palavra
-- Execute no SQL Editor do Supabase (uma única vez).
-- ============================================================

-- Extensão para UUIDs
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- LEADS
-- Um registro por número de WhatsApp.
-- ============================================================
CREATE TABLE IF NOT EXISTS leads (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  numero              TEXT UNIQUE NOT NULL,
  etapa               TEXT NOT NULL DEFAULT 'inicio',
  tentativas_followup INT  NOT NULL DEFAULT 0,
  pausado             BOOLEAN NOT NULL DEFAULT FALSE,
  ultima_mensagem     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  criado_em           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  atualizado_em       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS leads_etapa_idx          ON leads (etapa);
CREATE INDEX IF NOT EXISTS leads_ultima_mensagem_idx ON leads (ultima_mensagem);
CREATE INDEX IF NOT EXISTS leads_pausado_idx         ON leads (pausado);

-- ============================================================
-- HISTÓRICO DE MENSAGENS
-- Fonte de verdade para montar o contexto enviado ao Claude.
-- ============================================================
CREATE TABLE IF NOT EXISTS historico (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id   UUID NOT NULL REFERENCES leads (id) ON DELETE CASCADE,
  role      TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  conteudo  TEXT NOT NULL,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS historico_lead_id_idx  ON historico (lead_id);
CREATE INDEX IF NOT EXISTS historico_criado_em_idx ON historico (lead_id, criado_em DESC);

-- ============================================================
-- CONTEXTO DO LEAD (chave-valor)
-- Armazena pistas detectadas naturalmente: idade_filho, dor_tela, etc.
-- ============================================================
CREATE TABLE IF NOT EXISTS lead_contexto (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id   UUID NOT NULL REFERENCES leads (id) ON DELETE CASCADE,
  chave     TEXT NOT NULL,
  valor     TEXT,
  criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (lead_id, chave)
);

CREATE INDEX IF NOT EXISTS lead_contexto_lead_id_idx ON lead_contexto (lead_id);

-- ============================================================
-- EVENTOS (funil de conversão)
-- Rastreia ações importantes para métricas.
-- ============================================================
CREATE TABLE IF NOT EXISTS eventos (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id   UUID NOT NULL REFERENCES leads (id) ON DELETE CASCADE,
  tipo      TEXT NOT NULL,
  payload   JSONB NOT NULL DEFAULT '{}',
  criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS eventos_lead_id_idx ON eventos (lead_id);
CREATE INDEX IF NOT EXISTS eventos_tipo_idx    ON eventos (tipo);
CREATE INDEX IF NOT EXISTS eventos_criado_em_idx ON eventos (criado_em DESC);

-- ============================================================
-- ROW LEVEL SECURITY
-- Desativado intencionalmente: o bot usa service_role key,
-- que bypassa RLS de qualquer forma. Ative somente se adicionar
-- acesso direto por usuários autenticados no futuro.
-- ============================================================
ALTER TABLE leads         DISABLE ROW LEVEL SECURITY;
ALTER TABLE historico     DISABLE ROW LEVEL SECURITY;
ALTER TABLE lead_contexto DISABLE ROW LEVEL SECURITY;
ALTER TABLE eventos       DISABLE ROW LEVEL SECURITY;
