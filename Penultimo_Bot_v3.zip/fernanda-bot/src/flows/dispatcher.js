'use strict';

// ============================================================
// dispatcher.js — Controle de fluxo e estado
//
// REGRA: A IA escreve. O dispatcher decide quando e o quê.
// ============================================================

const { criarLogger }           = require('../services/logger');
const db                        = require('../services/database');
const claude                    = require('../services/claude');
const whatsapp                  = require('../services/whatsapp');
const { podeEnviar,
        registrarEnvio,
        podeEnviarLink,
        registrarLinkEnviado }  = require('../middlewares/antiSpam');
const { esperar,
        delayDigitacao }        = require('../utils/delays');
const { SYSTEM_BASE,
        construirInstrucao,
        instrucaoParaObjecaoLocal } = require('../prompts/fernanda');
const { analisarMensagemOnboarding } = require('./onboarding');
const { analisarMensagem,
        avaliarProgressao }     = require('./discovery');
const { detectarConfirmacaoCompra,
        deveEnviarLink,
        contextoFechamento }    = require('./sales');
const followupScheduler         = require('./followup');
const { FUNIL }                 = require('../config/constants');

const log = criarLogger({ modulo: 'dispatcher' });

const COOLDOWN_ENTRE_PARTES_MS = 1_500;
const ETAPAS = FUNIL.ETAPAS;

// ============================================================
// HELPERS
// ============================================================

function indiceEtapa(etapa) {
  return ETAPAS.indexOf(etapa);
}

function tempoMinimoRespeitado(lead) {
  const tempoMinS = FUNIL.TEMPO_MINIMO_ETAPA_S[lead.etapa] || 0;
  if (tempoMinS === 0) return true;
  const entrada = lead.etapa_entrada_em
    ? new Date(lead.etapa_entrada_em).getTime()
    : new Date(lead.criado_em).getTime();
  return (Date.now() - entrada) >= tempoMinS * 1000;
}

function limiteMsgAtingido(lead) {
  const limite = FUNIL.LIMITE_MSGS_POR_ETAPA[lead.etapa] ?? 99;
  return (lead.msgs_etapa_atual || 0) >= limite;
}

function limiteConversaAtingido(lead) {
  return (lead.total_msgs_fernanda || 0) >= FUNIL.MAX_MSGS_CONVERSA;
}

// ============================================================
// DETECÇÃO DE PISTAS
// ============================================================

async function detectarPistas(lead, texto) {
  const contextoAtual = await db.obterContexto(lead.id);
  const onboarding    = analisarMensagemOnboarding(texto, lead.total_msgs_mae || 0);
  const analise       = analisarMensagem(texto, contextoAtual);

  const novosContextos = { ...analise.novos_contextos };
  if (onboarding.nome_filho)  novosContextos.nome_filho  = onboarding.nome_filho;
  if (onboarding.idade_filho) novosContextos.idade_filho = onboarding.idade_filho;

  for (const [chave, valor] of Object.entries(novosContextos)) {
    try { await db.salvarContexto(lead.id, chave, valor); }
    catch (err) { log.warn({ chave, err: err.message }, 'Falha ao salvar contexto'); }
  }

  return {
    contextoAtualizado: { ...contextoAtual, ...novosContextos },
    analise,
    onboarding,
  };
}

// ============================================================
// MÁQUINA DE ESTADOS — simples e direta
// ============================================================

function decidirEtapa(lead, analise, progressao, onboarding) {
  const etapa = lead.etapa;

  // Condições de parada
  if (analise.sinais_abandono)          return { novaEtapa: 'pausado', motivo: 'abandono' };
  if (limiteConversaAtingido(lead))     return { novaEtapa: 'pausado', motivo: 'limite_conversa' };
  if (detectarConfirmacaoCompra(lead._ultimo_texto_mae || ''))
                                        return { novaEtapa: 'pausado', motivo: 'compra_confirmada' };

  // Atalho direto para fechamento
  if (progressao.deveAnteciparFechamento && indiceEtapa(etapa) < indiceEtapa('fechamento')) {
    return { novaEtapa: 'fechamento', motivo: 'sinal_compra_direto' };
  }

  // Followup respondeu → volta pro fechamento
  if (etapa === 'followup') {
    return { novaEtapa: 'fechamento', motivo: 'respondeu_followup' };
  }

  // Progressão normal
  switch (etapa) {
    case 'inicio':
      if (onboarding.pronto_para_avan || limiteMsgAtingido(lead))
        return { novaEtapa: 'conexao', motivo: 'idade_captada' };
      break;

    case 'conexao':
      if (tempoMinimoRespeitado(lead) && limiteMsgAtingido(lead))
        return { novaEtapa: 'descoberta', motivo: 'conexao_feita' };
      break;

    case 'descoberta': {
      const temDor = progressao.scoreEmocional >= 10;
      if ((temDor && tempoMinimoRespeitado(lead)) || limiteMsgAtingido(lead))
        return { novaEtapa: 'dor', motivo: 'dor_identificada' };
      break;
    }

    case 'dor':
      if ((progressao.prontoPraApresentacao && tempoMinimoRespeitado(lead)) || limiteMsgAtingido(lead))
        return { novaEtapa: 'apresentacao', motivo: 'pronto' };
      break;

    case 'apresentacao':
      if ((progressao.prontoPraFechamento && tempoMinimoRespeitado(lead)) || limiteMsgAtingido(lead))
        return { novaEtapa: 'prova', motivo: 'interesse_confirmado' };
      break;

    case 'prova':
      if ((progressao.scoreCompra >= 30 && tempoMinimoRespeitado(lead)) || limiteMsgAtingido(lead))
        return { novaEtapa: 'fechamento', motivo: 'prova_concluida' };
      break;

    case 'fechamento':
    case 'pausado':
      break;

    default: break;
  }

  return { novaEtapa: etapa, motivo: 'sem_mudanca' };
}

// ============================================================
// INSTRUÇÃO DA ETAPA
// ============================================================

function montarInstrucao(etapa, contexto, analise, lead) {
  // Objeção tem prioridade nas etapas de venda
  if (analise.objecoes.length > 0 && ['apresentacao', 'prova', 'fechamento'].includes(etapa)) {
    const instrObjecao = instrucaoParaObjecaoLocal(analise.objecoes);
    if (instrObjecao) return instrObjecao;
  }

  const ctx = etapa === 'fechamento'
    ? contextoFechamento(contexto, podeEnviarLink(lead.numero))
    : contexto;

  return construirInstrucao(etapa, ctx, {
    tentativa_followup: lead.tentativas_followup || 1,
  });
}

// ============================================================
// ENVIO COM TYPING NATURAL
// ============================================================

async function enviarResposta(numero, partes, isLink = false) {
  for (let i = 0; i < partes.length; i++) {
    const parte = partes[i];

    if (!podeEnviar(numero)) {
      log.warn({ numero }, 'Anti-spam: limite atingido');
      break;
    }

    const ms = delayDigitacao(parte);
    await whatsapp.enviarDigitando(numero, ms);
    await esperar(ms);
    await whatsapp.enviarMensagem(numero, parte);
    registrarEnvio(numero);

    if (i < partes.length - 1) await esperar(COOLDOWN_ENTRE_PARTES_MS);
  }

  if (isLink) registrarLinkEnviado(numero);
}

// ============================================================
// PERSISTÊNCIA
// ============================================================

async function persistirEstado(lead, novaEtapa, analise, progressao) {
  const mudouEtapa = novaEtapa !== lead.etapa;
  const campos = {
    etapa:               novaEtapa,
    score_interesse:     Math.min(100, Math.max(0, (lead.score_interesse || 0) + analise.delta_score_interesse)),
    score_emocional:     Math.min(100, Math.max(0, (lead.score_emocional || 0) + analise.delta_score_emocional)),
    score_compra:        Math.min(100, Math.max(0, (lead.score_compra    || 0) + analise.delta_score_compra)),
    msgs_etapa_atual:    mudouEtapa ? 1 : (lead.msgs_etapa_atual || 0) + 1,
    total_msgs_fernanda: (lead.total_msgs_fernanda || 0) + 1,
    total_msgs_mae:      (lead.total_msgs_mae      || 0) + 1,
    ultima_mensagem:     new Date().toISOString(),
    pausado:             novaEtapa === 'pausado',
  };
  if (mudouEtapa) campos.etapa_entrada_em = new Date().toISOString();
  return db.atualizarLead(lead.numero, campos);
}

// ============================================================
// FOLLOW-UP
// ============================================================

async function processarFollowup(lead) {
  const tentativa = (lead.tentativas_followup || 0) + 1;
  log.info({ numero: lead.numero, tentativa }, 'Follow-up');

  if (tentativa > FUNIL.LIMITE_MSGS_POR_ETAPA.followup) {
    await db.atualizarLead(lead.numero, { pausado: true, etapa: 'pausado', atualizado_em: new Date().toISOString() });
    return;
  }

  if (!podeEnviar(lead.numero)) return;

  const contexto  = await db.obterContexto(lead.id);
  const historico = await db.obterHistorico(lead.id, 6);
  const instrucao = construirInstrucao('followup', contexto, { tentativa_followup: tentativa });

  const { partes } = await claude.gerarResposta({
    numero:            lead.numero,
    textoUsuario:      '[SISTEMA: envie o follow-up agora]',
    historico,
    contexto,
    etapa:             'followup',
    instrucaoEtapa:    instrucao,
    systemPrompt:      SYSTEM_BASE,
    historicoFernanda: historico.filter(h => h.role === 'assistant').map(h => h.content),
  });

  await enviarResposta(lead.numero, partes);
  await db.inserirHistorico(lead.id, 'assistant', partes.join(' '));
  await db.atualizarLead(lead.numero, {
    tentativas_followup: tentativa,
    etapa:               'followup',
    ultima_mensagem:     new Date().toISOString(),
  });
  await db.registrarEvento(lead.id, 'followup_enviado', { tentativa });
}

// ============================================================
// PROCESSADOR PRINCIPAL
// ============================================================

async function processarMensagem(numero, texto) {
  log.info({ numero, chars: texto.length }, 'Mensagem recebida');

  let lead;
  try { lead = await db.obterOuCriarLead(numero); }
  catch (err) { log.error({ numero, err: err.message }, 'Falha ao obter lead'); return; }

  lead._ultimo_texto_mae = texto;

  if (lead.pausado || lead.etapa === 'pausado') {
    log.info({ numero }, 'Lead pausado — ignorando');
    return;
  }

  try { await db.inserirHistorico(lead.id, 'user', texto); }
  catch (err) { log.warn({ err: err.message }, 'Falha ao salvar histórico da mãe'); }

  const { contextoAtualizado, analise, onboarding } = await detectarPistas(lead, texto);
  const progressao = avaliarProgressao(lead, analise);
  const { novaEtapa, motivo } = decidirEtapa(lead, analise, progressao, onboarding);

  if (novaEtapa !== lead.etapa) {
    log.info({ numero, de: lead.etapa, para: novaEtapa, motivo }, 'Transição');
    await db.registrarEvento(lead.id, 'etapa_mudou', { de: lead.etapa, para: novaEtapa, motivo });
  }

  if (novaEtapa === 'pausado') {
    await db.atualizarLead(numero, { etapa: 'pausado', pausado: true, atualizado_em: new Date().toISOString() });
    return;
  }

  let historico = [];
  try { historico = await db.obterHistorico(lead.id, 12); }
  catch (err) { log.warn({ err: err.message }, 'Falha ao carregar histórico'); }

  const instrucao = montarInstrucao(novaEtapa, contextoAtualizado, analise, lead);

  let partes = [];
  try {
    const resultado = await claude.gerarResposta({
      numero,
      textoUsuario:      texto,
      historico,
      contexto:          contextoAtualizado,
      etapa:             novaEtapa,
      instrucaoEtapa:    instrucao,
      systemPrompt:      SYSTEM_BASE,
      historicoFernanda: historico.filter(h => h.role === 'assistant').map(h => h.content),
    });
    partes = resultado.partes;
    log.info({ numero, etapa: novaEtapa, partes: partes.length, tokens: resultado.tokens }, 'Resposta gerada');
  } catch (err) {
    log.error({ numero, err: err.message }, 'Falha ao gerar resposta');
    return;
  }

  if (!partes || partes.length === 0) return;

  const incluirLink = deveEnviarLink({
    etapa:          novaEtapa,
    podeEnviarLink: podeEnviarLink(numero),
    scoreCompra:    progressao.scoreCompra,
    sinalCompra:    analise.sinal_compra_direta,
  });

  await enviarResposta(numero, partes, incluirLink);

  try { await db.inserirHistorico(lead.id, 'assistant', partes.join(' ')); }
  catch (err) { log.warn({ err: err.message }, 'Falha ao salvar resposta'); }

  try { lead = await persistirEstado(lead, novaEtapa, analise, progressao); }
  catch (err) { log.error({ err: err.message }, 'Falha ao persistir estado'); }

  if (incluirLink) {
    await db.registrarEvento(lead.id, 'link_enviado', { etapa: novaEtapa, score_compra: progressao.scoreCompra })
      .catch(err => log.warn({ err: err.message }, 'Falha ao registrar evento link'));
  }

  log.info({ numero, etapa: novaEtapa }, 'Processado');
}

// ============================================================
// INICIALIZAÇÃO
// ============================================================

function inicializar() {
  followupScheduler.registrarProcessador(processarFollowup);
  followupScheduler.iniciar();
  log.info('Dispatcher inicializado');
}

module.exports = { processarMensagem, processarFollowup, inicializar };
