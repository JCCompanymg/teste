'use strict';

// ============================================================
// flows/sales.js — Lógica de venda: link, fechamento, compra
// ============================================================

const PADROES_CONFIRMACAO_COMPRA = [
  /comprei/i,
  /j[aá] (paguei|finalizei|fiz o pedido)/i,
  /deu certo/i,
  /recebi (o email|a confirmação)/i,
  /pedido (confirmado|feito)/i,
];

function detectarConfirmacaoCompra(texto) {
  return PADROES_CONFIRMACAO_COMPRA.some(p => p.test(texto));
}

function deveEnviarLink({ etapa, podeEnviarLink, scoreCompra, sinalCompra }) {
  if (etapa !== 'fechamento') return false;
  if (!podeEnviarLink) return false;
  if (scoreCompra < 20 && !sinalCompra) return false;
  return true;
}

function contextoFechamento(contexto, podeEnviarLinkAtual) {
  return {
    ...contexto,
    pode_enviar_link: podeEnviarLinkAtual,
    valor_avista:     'R$ 97',
    valor_parcelado:  'R$ 127',
    garantia_dias:    7,
  };
}

module.exports = {
  detectarConfirmacaoCompra,
  deveEnviarLink,
  contextoFechamento,
};
