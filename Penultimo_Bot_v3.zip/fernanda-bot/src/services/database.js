const { createClient } = require('@supabase/supabase-js');

// ============================================================
// INICIALIZAÇÃO
// ============================================================
let supabase;

function getClient() {
  if (!supabase) {
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_KEY;
    if (!url || !key) throw new Error('[database] SUPABASE_URL e SUPABASE_SERVICE_KEY são obrigatórios.');
    supabase = createClient(url, key, {
      auth: { persistSession: false }
    });
  }
  return supabase;
}

// ============================================================
// HELPERS INTERNOS
// ============================================================

// Lança erro com contexto claro em vez de engolir silenciosamente
function assertNoError(result, operacao) {
  if (result.error) {
    const err = new Error(`[database] Falha em "${operacao}": ${result.error.message}`);
    err.original = result.error;
    throw err;
  }
  return result.data;
}

// ============================================================
// LEADS
// ============================================================

/**
 * Busca um lead pelo número. Se não existir, cria com etapa 'inicio'.
 * Operação atômica via upsert — segura para concorrência.
 */
async function obterOuCriarLead(numero) {
  const db = getClient();

  const upsert = await db
    .from('leads')
    .upsert(
      { numero, etapa: 'inicio' },
      { onConflict: 'numero', ignoreDuplicates: true }
    )
    .select()
    .single();

  // Se já existia, ignoreDuplicates=true retorna null — busca explicitamente
  if (!upsert.data) {
    const select = await db
      .from('leads')
      .select('*')
      .eq('numero', numero)
      .single();
    return assertNoError(select, 'obterOuCriarLead:select');
  }

  return assertNoError(upsert, 'obterOuCriarLead:upsert');
}

/**
 * Atualiza campos do lead. Aceita qualquer subconjunto das colunas.
 * Sempre atualiza atualizado_em.
 */
async function atualizarLead(numero, campos) {
  const db = getClient();
  const result = await db
    .from('leads')
    .update({ ...campos, atualizado_em: new Date().toISOString() })
    .eq('numero', numero)
    .select()
    .single();
  return assertNoError(result, 'atualizarLead');
}

/**
 * Retorna todos os leads em determinada etapa.
 * Útil para o scheduler de follow-up.
 */
async function listarLeadsPorEtapa(etapa) {
  const db = getClient();
  const result = await db
    .from('leads')
    .select('*')
    .eq('etapa', etapa)
    .eq('pausado', false);
  return assertNoError(result, 'listarLeadsPorEtapa');
}

/**
 * Retorna leads elegíveis para follow-up:
 * - etapa 'conversando' (ou passada como parâmetro)
 * - não pausados
 * - follow-up não enviado (ou abaixo do limite de tentativas)
 * - última mensagem há mais de {minutosInativo} minutos
 */
async function listarLeadsParaFollowup({ minutosInativo = 120, maxTentativas = 2 } = {}) {
  const db = getClient();
  const limite = new Date(Date.now() - minutosInativo * 60 * 1000).toISOString();

  const result = await db
    .from('leads')
    .select('*')
    .eq('pausado', false)
    .lt('ultima_mensagem', limite)
    .lt('tentativas_followup', maxTentativas)
    .not('etapa', 'in', '("inicio","pausado")');

  return assertNoError(result, 'listarLeadsParaFollowup');
}

// ============================================================
// HISTÓRICO DE MENSAGENS
// ============================================================

/**
 * Insere uma mensagem no histórico.
 * role: 'user' (mae) ou 'assistant' (Fernanda)
 */
async function inserirHistorico(leadId, role, conteudo) {
  const db = getClient();
  const result = await db
    .from('historico')
    .insert({ lead_id: leadId, role, conteudo })
    .select()
    .single();
  return assertNoError(result, 'inserirHistorico');
}

/**
 * Retorna as últimas N mensagens do histórico no formato
 * esperado pela API Claude: [{ role, content }]
 */
async function obterHistorico(leadId, limite = 12) {
  const db = getClient();
  const result = await db
    .from('historico')
    .select('role, conteudo')
    .eq('lead_id', leadId)
    .order('criado_em', { ascending: false })
    .limit(limite);

  const data = assertNoError(result, 'obterHistorico');

  // Retorna em ordem cronológica (mais antiga primeiro) para o Claude
  return data.reverse().map(h => ({ role: h.role, content: h.conteudo }));
}

// ============================================================
// CONTEXTO DO LEAD (chave-valor)
// ============================================================

/**
 * Salva ou atualiza um par chave-valor de contexto do lead.
 * Ex: { chave: 'idade_filho', valor: '5 anos' }
 */
async function salvarContexto(leadId, chave, valor) {
  const db = getClient();
  const result = await db
    .from('lead_contexto')
    .upsert(
      { lead_id: leadId, chave, valor },
      { onConflict: 'lead_id,chave' }
    )
    .select()
    .single();
  return assertNoError(result, 'salvarContexto');
}

/**
 * Retorna todo o contexto do lead como objeto plano.
 * Ex: { idade_filho: '5 anos', dor_tela: 'mencionou tela' }
 */
async function obterContexto(leadId) {
  const db = getClient();
  const result = await db
    .from('lead_contexto')
    .select('chave, valor')
    .eq('lead_id', leadId);

  const data = assertNoError(result, 'obterContexto');
  return Object.fromEntries(data.map(r => [r.chave, r.valor]));
}

// ============================================================
// EVENTOS (rastreamento de funil)
// ============================================================

/**
 * Registra um evento rastreável para métricas de conversão.
 * tipo: 'mensagem_recebida' | 'etapa_mudou' | 'link_enviado' |
 *       'followup_enviado' | 'erro_claude' | etc.
 */
async function registrarEvento(leadId, tipo, payload = {}) {
  const db = getClient();
  const result = await db
    .from('eventos')
    .insert({ lead_id: leadId, tipo, payload })
    .select()
    .single();
  return assertNoError(result, 'registrarEvento');
}

// ============================================================
// EXPORTS
// ============================================================
module.exports = {
  // leads
  obterOuCriarLead,
  atualizarLead,
  listarLeadsPorEtapa,
  listarLeadsParaFollowup,
  // histórico
  inserirHistorico,
  obterHistorico,
  // contexto
  salvarContexto,
  obterContexto,
  // eventos
  registrarEvento,
};
