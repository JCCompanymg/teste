'use strict';

// ============================================================
// claude.js — Integração com a API Claude (Anthropic)
//
// RESPONSABILIDADES:
//   - Chamar a API com timeout, retry e backoff exponencial
//   - Truncar histórico inteligentemente (controle de tokens)
//   - Sanitizar input e output
//   - Prevenir respostas longas e fora do estilo WhatsApp
//   - Detectar e bloquear loops conversacionais
//   - Registrar métricas de uso e latência
//   - Fallback seguro em caso de falha total
//
// NÃO FAZ:
//   - Decidir o que a Fernanda vai dizer (isso é do dispatcher)
//   - Controlar estados ou transições de funil
//   - Enviar mensagens (isso é do whatsapp.js)
//
// CONTRATO COM O DISPATCHER:
//   gerarResposta(opcoes) → { texto, partes, tokens, latencia, cached }
//   quebrarEmPartes(texto) → string[]
// ============================================================

const { criarLogger } = require('./logger');

const log = criarLogger({ modulo: 'claude' });

// ============================================================
// CONSTANTES
// ============================================================

const API_URL     = 'https://api.anthropic.com/v1/messages';
const API_VERSION = '2023-06-01';
const MODEL       = 'claude-sonnet-4-20250514';

// Limites de tokens
const MAX_TOKENS_RESPOSTA   = 400;   // Fernanda nunca escreve textão
const MAX_TOKENS_HISTORICO  = 3_000; // Janela de contexto enviada à API
const TOKENS_POR_CHAR       = 0.35;  // Estimativa conservadora pt-BR

// Controle de requisição
const TIMEOUT_MS            = 28_000; // 28s — abaixo do timeout do Railway (30s)
const MAX_TENTATIVAS        = 3;
const BACKOFF_BASE_MS       = 1_500;
const BACKOFF_MAX_MS        = 12_000;
const BACKOFF_JITTER_MS     = 800;

// Controle de qualidade de resposta
const MAX_CHARS_RESPOSTA     = 800;   // ~400 tokens — limite hard de output
const MIN_CHARS_RESPOSTA     = 8;     // Resposta abaixo disso é inválida
const MAX_PARTES_QUEBRA      = 4;     // Máximo de mensagens por resposta
const SEPARADOR_QUEBRA       = '|||QUEBRA|||';

// Detecção de loop conversacional
const JANELA_LOOP_MSGS       = 6;     // Últimas N mensagens a analisar
const SIMILARIDADE_LOOP      = 0.82;  // % de tokens em comum = loop

// Cache leve — evita chamada duplicada se mesmo texto chegar 2x seguidas
// (proteção extra contra race condition no debounce)
const CACHE_TTL_MS           = 8_000;
const cacheRecente = new Map(); // Map<chaveCache, { texto, expira }>

// Métricas acumuladas (em memória — Railway reseta a cada deploy)
const metricas = {
  chamadas:         0,
  erros:            0,
  timeouts:         0,
  cacheHits:        0,
  tokensUsados:     0,
  latenciaTotal:    0,
  retries:          0,
  fallbacksUsados:  0,
};

// ============================================================
// HELPERS — ESTIMATIVA DE TOKENS
// ============================================================

/**
 * Estima tokens de uma string em português brasileiro.
 * Mais conservador que o real para garantir que não estoure.
 */
function estimarTokens(texto) {
  if (!texto || typeof texto !== 'string') return 0;
  return Math.ceil(texto.length * TOKENS_POR_CHAR);
}

/**
 * Estima tokens totais de um array de mensagens de histórico.
 */
function estimarTokensHistorico(historico) {
  return historico.reduce((acc, msg) => acc + estimarTokens(msg.content) + 4, 0);
}

// ============================================================
// TRUNCAMENTO INTELIGENTE DE HISTÓRICO
// ============================================================

/**
 * Reduz o histórico ao que cabe dentro do budget de tokens.
 *
 * Estratégia:
 *   1. Sempre mantém a mensagem mais recente do usuário (âncora)
 *   2. Preenche com mensagens anteriores da mais recente pra mais antiga
 *   3. Garante que a janela comece com mensagem do usuário (não do assistant)
 *      para respeitar o formato alternado exigido pela API
 */
function truncarHistorico(historico, budgetTokens) {
  if (!historico || historico.length === 0) return [];

  // A mensagem atual do usuário já vai no campo separado — não inclui no histórico
  const hist = [...historico];

  // Já cabe tudo?
  if (estimarTokensHistorico(hist) <= budgetTokens) return hist;

  // Remove do início até caber no budget
  while (hist.length > 0 && estimarTokensHistorico(hist) > budgetTokens) {
    hist.shift();
  }

  // Garante que começa com mensagem do usuário (regra da API)
  while (hist.length > 0 && hist[0].role !== 'user') {
    hist.shift();
  }

  return hist;
}

// ============================================================
// SANITIZAÇÃO
// ============================================================

/**
 * Sanitiza o texto do usuário antes de enviar à API.
 * Remove caracteres de controle, limita tamanho, normaliza espaços.
 */
function sanitizarInput(texto) {
  if (!texto || typeof texto !== 'string') return '';

  return texto
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '') // controles exceto \t \n \r
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 1_200); // máximo 1200 chars de input por segurança
}

/**
 * Sanitiza a resposta da Fernanda antes de entregar ao dispatcher.
 * Remove artefatos de markdown, limita tamanho, normaliza quebras.
 */
function sanitizarOutput(texto) {
  if (!texto || typeof texto !== 'string') return '';

  return texto
    .replace(/\*\*(.*?)\*\*/g, '$1')       // bold markdown
    .replace(/\*(.*?)\*/g, '$1')           // italic markdown
    .replace(/^#+\s+/gm, '')              // headers markdown
    .replace(/^[-•]\s+/gm, '')            // bullet points
    .replace(/^\d+\.\s+/gm, '')           // numbered lists
    .replace(/`{1,3}[^`]*`{1,3}/g, '')    // inline/block code
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // links markdown
    .replace(/\n{3,}/g, '\n\n')           // excesso de quebras
    .trim()
    .slice(0, MAX_CHARS_RESPOSTA);
}

// ============================================================
// DETECÇÃO DE LOOP CONVERSACIONAL
// ============================================================

/**
 * Detecta se a resposta gerada é muito similar a uma resposta recente.
 * Usa comparação de bigramas para capturar parafrasings óbvios.
 *
 * Retorna true se for loop (resposta deve ser descartada/reescrita).
 */
function detectarLoop(respostaGerada, historicoFernanda) {
  if (!historicoFernanda || historicoFernanda.length === 0) return false;

  const recentes = historicoFernanda.slice(-JANELA_LOOP_MSGS);
  const bigramasResposta = extrairBigramas(respostaGerada.toLowerCase());

  if (bigramasResposta.size === 0) return false;

  for (const msgAnterior of recentes) {
    const bigramasAnteriores = extrairBigramas(msgAnterior.toLowerCase());
    const intersecao = [...bigramasResposta].filter(b => bigramasAnteriores.has(b)).length;
    const similaridade = intersecao / Math.max(bigramasResposta.size, 1);

    if (similaridade >= SIMILARIDADE_LOOP) {
      log.warn({ similaridade: similaridade.toFixed(2) }, 'Loop detectado na resposta');
      return true;
    }
  }

  return false;
}

function extrairBigramas(texto) {
  const palavras = texto.split(/\s+/).filter(p => p.length > 2);
  const bigramas = new Set();
  for (let i = 0; i < palavras.length - 1; i++) {
    bigramas.add(`${palavras[i]}|${palavras[i + 1]}`);
  }
  return bigramas;
}

// ============================================================
// VALIDAÇÃO DE RESPOSTA
// ============================================================

/**
 * Verifica se a resposta gerada é válida para envio.
 * Rejeita respostas vazias, muito curtas, com marcadores de IA, etc.
 */
function validarResposta(texto) {
  if (!texto || typeof texto !== 'string') {
    return { valida: false, motivo: 'vazia' };
  }

  const limpo = texto.trim();

  if (limpo.length < MIN_CHARS_RESPOSTA) {
    return { valida: false, motivo: 'muito_curta' };
  }

  // Detecta frases que indicam que a IA saiu do personagem
  const MARCADORES_IA = [
    /\bcomo (ia|intelig[eê]ncia artificial|assistente virtual|bot|chatbot)\b/i,
    /\bsou (um|uma) (ia|rob[oô]|programa|sistema|software)\b/i,
    /\bnão (tenho|possuo) (sentimentos?|emo[çc][oõ]es?|corpo|exist[eê]ncia f[ií]sica)\b/i,
    /\bcomo (modelo de linguagem|llm)\b/i,
    /\banthrop[ií]c\b/i,
    /\bclaude\b/i,
    /\bfui (treinado|programado|desenvolvido)\b/i,
    /\bminha (base de (dados|conhecimento)|arquitetura)\b/i,
  ];

  for (const padrao of MARCADORES_IA) {
    if (padrao.test(limpo)) {
      return { valida: false, motivo: 'quebra_personagem' };
    }
  }

  // Detecta resposta genérica de erro que a IA às vezes gera
  const RESPOSTAS_GENERICAS = [
    /^(desculp[ae]|me desculp[ae])[,.]?\s*n[aã]o (consigo|posso|entendi)/i,
    /^infelizmente n[aã]o (consigo|posso)/i,
    /^n[aã]o (tenho|possuo) informa[çc][aã]o/i,
  ];

  for (const padrao of RESPOSTAS_GENERICAS) {
    if (padrao.test(limpo)) {
      return { valida: false, motivo: 'resposta_generica_erro' };
    }
  }

  return { valida: true, motivo: null };
}

// ============================================================
// CACHE LEVE
// ============================================================

function chaveCache(numero, textoUsuario, etapa) {
  return `${numero}:${etapa}:${textoUsuario.slice(0, 60)}`;
}

function verificarCache(chave) {
  const entrada = cacheRecente.get(chave);
  if (!entrada) return null;
  if (Date.now() > entrada.expira) {
    cacheRecente.delete(chave);
    return null;
  }
  return entrada.texto;
}

function salvarCache(chave, texto) {
  // Limpa entradas expiradas antes de inserir (evita vazamento de memória)
  const agora = Date.now();
  for (const [k, v] of cacheRecente) {
    if (agora > v.expira) cacheRecente.delete(k);
  }
  cacheRecente.set(chave, { texto, expira: agora + CACHE_TTL_MS });
}

// ============================================================
// BACKOFF EXPONENCIAL
// ============================================================

function calcularBackoff(tentativa) {
  const base   = Math.min(BACKOFF_BASE_MS * Math.pow(2, tentativa), BACKOFF_MAX_MS);
  const jitter = Math.random() * BACKOFF_JITTER_MS;
  return Math.floor(base + jitter);
}

function esperar(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ============================================================
// CHAMADA À API — FETCH COM TIMEOUT
// ============================================================

/**
 * Faz uma chamada à API com timeout hard via AbortController.
 * Retorna o objeto de resposta parseado ou lança erro com contexto.
 */
async function chamarAPI({ systemPrompt, mensagens, temperatura = 0.85 }) {
  const apiKey = process.env.CLAUDE_API_KEY;
  if (!apiKey) throw new Error('[claude] CLAUDE_API_KEY não configurada');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  const body = JSON.stringify({
    model:      MODEL,
    max_tokens: MAX_TOKENS_RESPOSTA,
    temperature: temperatura,
    system:     systemPrompt,
    messages:   mensagens,
  });

  let resposta;
  try {
    resposta = await fetch(API_URL, {
      method:  'POST',
      headers: {
        'Content-Type':      'application/json',
        'x-api-key':         apiKey,
        'anthropic-version': API_VERSION,
      },
      body,
      signal: controller.signal,
    });
  } catch (err) {
    if (err.name === 'AbortError') {
      metricas.timeouts++;
      throw new Error(`[claude] Timeout após ${TIMEOUT_MS}ms`);
    }
    throw new Error(`[claude] Erro de rede: ${err.message}`);
  } finally {
    clearTimeout(timer);
  }

  // Tratar erros HTTP com contexto
  if (!resposta.ok) {
    let detalhe = '';
    try {
      const corpo = await resposta.json();
      detalhe = corpo?.error?.message || JSON.stringify(corpo);
    } catch (_) {
      detalhe = await resposta.text().catch(() => '');
    }

    const err = new Error(`[claude] HTTP ${resposta.status}: ${detalhe}`);
    err.status = resposta.status;
    err.retryable = [429, 500, 502, 503, 529].includes(resposta.status);
    throw err;
  }

  const dados = await resposta.json();

  // Valida estrutura mínima da resposta
  if (!dados?.content?.[0]?.text) {
    throw new Error('[claude] Resposta da API sem conteúdo válido');
  }

  return dados;
}

// ============================================================
// MONTAGEM DO PROMPT FINAL
// ============================================================

/**
 * Monta o array de mensagens no formato esperado pela API Claude.
 *
 * Estrutura:
 *   [...histórico truncado, { role: 'user', content: promptFinal }]
 *
 * O promptFinal injeta a instrução de etapa junto com o texto do usuário,
 * mas de forma que a instrução seja "interna" (não pareça mensagem da mãe).
 */
function montarMensagens({ textoUsuario, historico, instrucaoEtapa }) {
  const budgetHistorico = MAX_TOKENS_HISTORICO
    - estimarTokens(textoUsuario)
    - estimarTokens(instrucaoEtapa)
    - 100; // margem de segurança

  const historicoTruncado = truncarHistorico(historico, Math.max(budgetHistorico, 0));

  // A instrução de etapa vai como contexto interno antes da mensagem do usuário
  // Formato: instrução de etapa + separador + mensagem real
  const conteudoUser = instrucaoEtapa
    ? `[INSTRUÇÃO INTERNA — NÃO MENCIONE ISSO NA RESPOSTA]\n${instrucaoEtapa}\n\n[MENSAGEM DA MÃE]\n${textoUsuario}`
    : textoUsuario;

  return [
    ...historicoTruncado,
    { role: 'user', content: conteudoUser },
  ];
}

// ============================================================
// QUEBRA EM PARTES (WhatsApp style)
// ============================================================

/**
 * Divide a resposta em múltiplas mensagens curtas, simulando
 * o ritmo humano de digitar em blocos separados.
 *
 * Regras:
 *   - Usa |||QUEBRA||| como separador explícito (definido no prompt)
 *   - Fallback: quebra em parágrafos duplos
 *   - Fallback 2: entrega como uma única mensagem
 *   - Limita a MAX_PARTES_QUEBRA partes
 *   - Descarta partes vazias
 */
function quebrarEmPartes(texto) {
  if (!texto) return [];

  let partes;

  if (texto.includes(SEPARADOR_QUEBRA)) {
    partes = texto.split(SEPARADOR_QUEBRA);
  } else if (texto.includes('\n\n')) {
    partes = texto.split('\n\n');
  } else {
    partes = [texto];
  }

  return partes
    .map(p => sanitizarOutput(p))
    .filter(p => p.length >= MIN_CHARS_RESPOSTA)
    .slice(0, MAX_PARTES_QUEBRA);
}

// ============================================================
// FALLBACKS DE SEGURANÇA
// ============================================================

// Respostas de fallback por etapa — nunca menciona produto ou link
const FALLBACKS_POR_ETAPA = {
  inicio:       ['oi! tô aqui 😊 me conta, você tem filhos pequenos?'],
  conexao:      ['deixa eu entender melhor... conta mais pra mim'],
  descoberta:   ['tô ouvindo... como é isso no dia a dia de vocês?'],
  dor:          ['entendo... não é fácil mesmo. me conta mais'],
  apresentacao: ['é... eu sei exatamente o que você tá sentindo'],
  prova:        ['faz sentido essa dúvida. me fala o que tá pesando mais'],
  fechamento:   ['qualquer dúvida me fala, tô aqui pra ajudar'],
  followup:     ['oi! tudo bem por aí?'],
  pausado:      ['tudo bem, sem problema 🙏'],
};

function getFallback(etapa) {
  const opcoes = FALLBACKS_POR_ETAPA[etapa] || FALLBACKS_POR_ETAPA.conexao;
  return opcoes[Math.floor(Math.random() * opcoes.length)];
}

// ============================================================
// FUNÇÃO PRINCIPAL: gerarResposta
// ============================================================

/**
 * Gera a resposta da Fernanda para uma mensagem do usuário.
 *
 * @param {object}   opcoes
 * @param {string}   opcoes.numero           - JID do WhatsApp (para logs/cache)
 * @param {string}   opcoes.textoUsuario     - Mensagem da mãe
 * @param {Array}    opcoes.historico        - Histórico [{role, content}]
 * @param {object}   opcoes.contexto         - Contexto do lead (dor, idade_filho, etc.)
 * @param {string}   opcoes.etapa            - Etapa atual do funil
 * @param {string}   opcoes.instrucaoEtapa   - Instrução montada pelo dispatcher
 * @param {string}   opcoes.systemPrompt     - SYSTEM_BASE da Fernanda
 * @param {string[]} opcoes.historicoFernanda - Últimas respostas da Fernanda (para detecção de loop)
 *
 * @returns {Promise<{texto: string, partes: string[], tokens: number, latencia: number, cached: boolean}>}
 */
async function gerarResposta({
  numero,
  textoUsuario,
  historico        = [],
  contexto         = {},
  etapa            = 'conexao',
  instrucaoEtapa   = '',
  systemPrompt     = '',
  historicoFernanda = [],
}) {
  const tsInicio = Date.now();
  metricas.chamadas++;

  // ── Sanitizar input ───────────────────────────────────────
  const textoSanitizado = sanitizarInput(textoUsuario);
  if (!textoSanitizado) {
    log.warn({ numero, etapa }, 'Input vazio após sanitização — usando fallback');
    const fallback = getFallback(etapa);
    metricas.fallbacksUsados++;
    return _retornarResposta(fallback, 0, Date.now() - tsInicio, false);
  }

  // ── Cache ─────────────────────────────────────────────────
  const cacheKey = chaveCache(numero, textoSanitizado, etapa);
  const cached   = verificarCache(cacheKey);
  if (cached) {
    metricas.cacheHits++;
    log.info({ numero, etapa }, 'Cache hit');
    return _retornarResposta(cached, 0, Date.now() - tsInicio, true);
  }

  // ── Montar mensagens ──────────────────────────────────────
  const mensagens = montarMensagens({
    textoUsuario:  textoSanitizado,
    historico,
    instrucaoEtapa,
  });

  log.info({
    numero,
    etapa,
    msgsTotais:    mensagens.length,
    tokensEst:     estimarTokensHistorico(mensagens),
    inputChars:    textoSanitizado.length,
  }, 'Iniciando chamada à API');

  // ── Retry com backoff ─────────────────────────────────────
  let ultimoErro;

  for (let tentativa = 0; tentativa < MAX_TENTATIVAS; tentativa++) {
    if (tentativa > 0) {
      const delay = calcularBackoff(tentativa - 1);
      log.warn({ numero, tentativa, delay }, 'Retry — aguardando backoff');
      metricas.retries++;
      await esperar(delay);
    }

    try {
      // Temperatura varia levemente entre retries para evitar resposta idêntica
      const temperatura = tentativa === 0 ? 0.85 : 0.75 + (Math.random() * 0.15);

      const dados = await chamarAPI({ systemPrompt, mensagens, temperatura });

      // ── Extrair texto ──────────────────────────────────
      const textoRaw    = dados.content[0].text || '';
      const tokensUsados = dados.usage?.output_tokens || estimarTokens(textoRaw);
      metricas.tokensUsados += tokensUsados;

      // ── Sanitizar output ───────────────────────────────
      const textoLimpo = sanitizarOutput(textoRaw);

      // ── Validar resposta ───────────────────────────────
      const { valida, motivo } = validarResposta(textoLimpo);
      if (!valida) {
        log.warn({ numero, etapa, motivo }, 'Resposta inválida — descartando e reprocessando');
        ultimoErro = new Error(`Resposta inválida: ${motivo}`);

        // Quebra de personagem é grave — não tenta de novo, vai pro fallback
        if (motivo === 'quebra_personagem') break;
        continue;
      }

      // ── Detectar loop ──────────────────────────────────
      if (detectarLoop(textoLimpo, historicoFernanda)) {
        log.warn({ numero, etapa, tentativa }, 'Loop detectado — retentando com temperatura maior');
        ultimoErro = new Error('Loop conversacional detectado');
        continue; // tenta de novo com temperatura diferente
      }

      // ── Substituir placeholder do link ────────────────
      const link = process.env.LINK_PAGAMENTO || 'pay.cakto.com.br';
      const textoFinal = textoLimpo.replace(/\{\{LINK_PAGAMENTO\}\}/g, link);

      // ── Salvar no cache ────────────────────────────────
      salvarCache(cacheKey, textoFinal);

      const latencia = Date.now() - tsInicio;
      metricas.latenciaTotal += latencia;

      log.info({
        numero,
        etapa,
        tentativa,
        tokens:   tokensUsados,
        chars:    textoFinal.length,
        latencia,
      }, 'Resposta gerada com sucesso');

      return _retornarResposta(textoFinal, tokensUsados, latencia, false);

    } catch (err) {
      ultimoErro = err;
      metricas.erros++;

      const retryable = err.retryable !== false; // por padrão tenta de novo
      log.error({
        numero,
        etapa,
        tentativa,
        status:    err.status,
        retryable,
        err:       err.message,
      }, 'Erro na chamada à API');

      // Erros não retentáveis (ex: 400 Bad Request) — vai pro fallback direto
      if (!retryable) break;

      // Rate limit (429) — espera mais antes de tentar
      if (err.status === 429) {
        await esperar(10_000 + Math.random() * 5_000);
      }
    }
  }

  // ── Fallback de segurança ─────────────────────────────────
  log.error({
    numero,
    etapa,
    ultimoErro: ultimoErro?.message,
  }, 'Todas as tentativas falharam — usando fallback');

  metricas.fallbacksUsados++;
  const textoFallback = getFallback(etapa);
  const latencia = Date.now() - tsInicio;
  metricas.latenciaTotal += latencia;

  return _retornarResposta(textoFallback, 0, latencia, false);
}

// ============================================================
// HELPER INTERNO — formata o retorno padrão
// ============================================================

function _retornarResposta(texto, tokens, latencia, cached) {
  return {
    texto,
    partes:   quebrarEmPartes(texto),
    tokens,
    latencia,
    cached,
  };
}

// ============================================================
// MÉTRICAS
// ============================================================

/**
 * Retorna snapshot das métricas acumuladas desde o último deploy.
 */
function obterMetricas() {
  const totalChamadas = metricas.chamadas || 1;
  return {
    ...metricas,
    taxaErro:          ((metricas.erros / totalChamadas) * 100).toFixed(1) + '%',
    taxaCacheHit:      ((metricas.cacheHits / totalChamadas) * 100).toFixed(1) + '%',
    latenciaMedia:     Math.round(metricas.latenciaTotal / totalChamadas) + 'ms',
    tokensMediaPorMsg: Math.round(metricas.tokensUsados / totalChamadas),
  };
}

/**
 * Reseta métricas (útil para testes ou reset manual via admin).
 */
function resetarMetricas() {
  Object.keys(metricas).forEach(k => { metricas[k] = 0; });
}

// ============================================================
// EXPORTS
// ============================================================

module.exports = {
  gerarResposta,
  quebrarEmPartes,
  obterMetricas,
  resetarMetricas,

  // Expostos para testes unitários
  _internos: {
    sanitizarInput,
    sanitizarOutput,
    truncarHistorico,
    detectarLoop,
    validarResposta,
    estimarTokens,
    estimarTokensHistorico,
    montarMensagens,
    calcularBackoff,
    getFallback,
    SEPARADOR_QUEBRA,
    MAX_TOKENS_RESPOSTA,
    MAX_TOKENS_HISTORICO,
    MAX_CHARS_RESPOSTA,
    MAX_PARTES_QUEBRA,
  },
};
