'use strict';

// ============================================================
// whatsapp.js — Serviço de conexão Baileys
//
// Responsabilidades:
//   - Manter UM único socket ativo (singleton)
//   - Reconectar com backoff exponencial + jitter
//   - Detectar e parar reconnect storm (antiLoop)
//   - Recuperar sessão salva em disco (auth_info/)
//   - Gerenciar QR code (exibe e expira após timeout)
//   - Fila de envio com rate limiting por número
//   - Envio humanizado: typing indicator + delay proporcional
//   - Emitir eventos para o dispatcher via EventEmitter
//
// NÃO faz:
//   - Processamento de mensagens (isso é do dispatcher)
//   - Lógica de negócio
//   - Chamadas à API Claude
// ============================================================

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  isJidGroup,
  makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');

const pino         = require('pino');
const qrcode       = require('qrcode-terminal');
const EventEmitter = require('events');
const { criarLogger } = require('./logger');
const { esperar, delayDigitacao, jitter } = require('../utils/delays');

const log = criarLogger({ modulo: 'whatsapp' });

// ============================================================
// CONSTANTES
// ============================================================

const AUTH_DIR = process.env.AUTH_DIR || 'auth_info';

// Backoff exponencial: tentativa N espera BASE * 2^N ms (+ jitter)
const BACKOFF_BASE_MS    = 2_000;
const BACKOFF_MAX_MS     = 120_000; // 2 minutos no máximo
const BACKOFF_JITTER_MS  = 3_000;

// Se ocorrerem N falhas em menos de STORM_JANELA_MS, para tudo
const STORM_MAX_FALHAS   = 5;
const STORM_JANELA_MS    = 60_000; // 1 minuto

// QR expira após esse tempo sem scan
const QR_TIMEOUT_MS      = 60_000; // 1 minuto

// Fila de envio: máximo de mensagens simultâneas saindo por número
const SEND_COOLDOWN_MS   = 1_200;  // gap mínimo entre envios pro mesmo número

// ============================================================
// ESTADO SINGLETON
// ============================================================

let sock              = null;   // socket ativo
let tentativasRecon   = 0;      // contador de reconexões
let reconectando      = false;  // lock para evitar reconexões paralelas
let destruido         = false;  // flag de shutdown intencional

const falhasRecentes  = [];     // timestamps de falhas para detecção de storm
const emitter         = new EventEmitter();

// Fila de envio: Map<numero, Promise> — serial por número, igual à queue de processamento
const filasEnvio      = new Map();

// ============================================================
// EVENTOS PÚBLICOS
// ============================================================
// Outros módulos escutam via whatsapp.on('mensagem', handler)
//
// 'mensagem'    — { numero, texto, msg } — nova mensagem de texto recebida
// 'conectado'   — socket pronto
// 'desconectado'— { motivo }
// 'qr'          — { qr } — novo QR gerado

// ============================================================
// BACKOFF EXPONENCIAL COM JITTER
// ============================================================

function calcularBackoff(tentativa) {
  const exponencial = BACKOFF_BASE_MS * Math.pow(2, tentativa);
  const limitado    = Math.min(exponencial, BACKOFF_MAX_MS);
  const comJitter   = limitado + Math.random() * BACKOFF_JITTER_MS;
  return Math.round(comJitter);
}

// ============================================================
// DETECÇÃO DE RECONNECT STORM
// ============================================================

function registrarFalha() {
  const agora = Date.now();
  falhasRecentes.push(agora);

  // Remove falhas fora da janela de observação
  while (falhasRecentes.length && falhasRecentes[0] < agora - STORM_JANELA_MS) {
    falhasRecentes.shift();
  }
}

function isReconnectStorm() {
  return falhasRecentes.length >= STORM_MAX_FALHAS;
}

// ============================================================
// DESTRUIÇÃO SEGURA DO SOCKET ATUAL
// ============================================================

async function destruirSocketAtual() {
  if (!sock) return;
  const socketAntigo = sock;
  sock = null;
  try {
    // Remove todos os listeners antes de fechar — evita que eventos
    // do socket morto disparem handlers do socket novo
    socketAntigo.ev.removeAllListeners();
    await socketAntigo.logout().catch(() => {}); // ignora erro de logout
    socketAntigo.end();
  } catch (e) {
    log.warn({ err: e.message }, 'Erro ao destruir socket (ignorado)');
  }
}

// ============================================================
// INICIALIZAÇÃO DO SOCKET
// ============================================================

async function criarSocket() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);

  let version;
  try {
    const resultado = await fetchLatestBaileysVersion();
    version = resultado.version;
    log.info({ version }, 'Versão Baileys obtida');
  } catch (e) {
    log.warn('Não foi possível buscar versão Baileys — usando fallback [2,3000,1023162856]');
    version = [2, 3000, 1023162856];
  }

  const novoSock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      // makeCacheableSignalKeyStore evita leituras síncronas repetidas de disco
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
    },
    logger: pino({ level: 'silent' }), // Baileys é muito verboso — silenciamos
    browser: ['Crescendo com a Palavra', 'Chrome', '120.0.0'],
    // Não manda presença automática (economiza conexões e reduz risco de ban)
    markOnlineOnConnect: false,
    // Não baixa histórico antigo na reconexão
    syncFullHistory: false,
    // Reconexão gerenciada por nós, não pelo Baileys
    retryRequestDelayMs: 500,
    maxMsgRetryCount: 2,
  });

  novoSock.ev.on('creds.update', saveCreds);

  // ── Conexão ──────────────────────────────────────────────
  novoSock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
    // QR Code
    if (qr) {
      log.info('QR gerado — aguardando scan');
      qrcode.generate(qr, { small: true });
      emitter.emit('qr', { qr });

      // QR expira — se não escaneou em QR_TIMEOUT_MS, reconecta
      setTimeout(() => {
        if (!sock || sock === novoSock) {
          log.warn('QR expirou sem scan — reconectando');
          agendarReconexao('qr_expirado');
        }
      }, QR_TIMEOUT_MS);
    }

    if (connection === 'open') {
      log.info('Socket conectado ao WhatsApp');
      tentativasRecon = 0;       // reset do contador de backoff
      reconectando    = false;
      falhasRecentes.splice(0);  // limpa histórico de falhas
      emitter.emit('conectado');
    }

    if (connection === 'close') {
      const status = lastDisconnect?.error?.output?.statusCode;
      const motivo = lastDisconnect?.error?.message || 'desconhecido';

      log.warn({ status, motivo }, 'Conexão fechada');
      emitter.emit('desconectado', { motivo, status });

      // Logout explícito: não reconectar — sessão foi revogada pelo WhatsApp
      if (status === DisconnectReason.loggedOut) {
        log.error('Sessão encerrada pelo WhatsApp (loggedOut). Apague auth_info/ e reinicie.');
        destruido = true;
        return;
      }

      agendarReconexao(motivo);
    }
  });

  // ── Mensagens recebidas ───────────────────────────────────
  novoSock.ev.on('messages.upsert', async ({ messages, type }) => {
    // 'notify' = mensagem nova. 'append' = histórico carregando — ignorar
    if (type !== 'notify') return;

    for (const msg of messages) {
      // Ignora mensagens próprias, sem conteúdo, de grupos
      if (msg.key.fromMe)                  continue;
      if (!msg.message)                    continue;
      if (isJidGroup(msg.key.remoteJid))   continue;

      const numero = msg.key.remoteJid;
      const texto  =
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        '';

      if (!texto.trim()) continue;

      log.info({ numero, chars: texto.length }, 'Mensagem recebida');
      emitter.emit('mensagem', { numero, texto: texto.trim(), msg });
    }
  });

  // ── Erros de stream ───────────────────────────────────────
  novoSock.ev.on('connection.update', ({ receivedPendingNotifications }) => {
    if (receivedPendingNotifications) {
      log.info('Notificações pendentes recebidas — socket estável');
    }
  });

  return novoSock;
}

// ============================================================
// RECONEXÃO COM BACKOFF EXPONENCIAL + ANTI-STORM
// ============================================================

async function agendarReconexao(motivo) {
  if (destruido)    return;
  if (reconectando) {
    log.warn({ motivo }, 'Reconexão já em andamento — ignorando chamada paralela');
    return;
  }

  registrarFalha();

  if (isReconnectStorm()) {
    const pausaMs = BACKOFF_MAX_MS;
    log.error(
      { falhasRecentes: falhasRecentes.length, pausaMs },
      'Reconnect storm detectado — pausando reconexão'
    );
    await esperar(pausaMs);
    falhasRecentes.splice(0); // reset após pausa longa
  }

  reconectando = true;
  await destruirSocketAtual();

  const delay = calcularBackoff(tentativasRecon);
  tentativasRecon++;

  log.info({ tentativa: tentativasRecon, delayMs: delay, motivo }, 'Reagendando conexão');
  await esperar(delay);

  if (destruido) { reconectando = false; return; }

  try {
    sock = await criarSocket();
    // reconectando é resetado dentro de 'connection.update' → 'open'
    // mas garantimos reset aqui caso criarSocket() falhe antes de abrir
  } catch (err) {
    reconectando = false;
    log.error({ err: err.message }, 'Falha ao criar socket — nova reconexão agendada');
    agendarReconexao('erro_criar_socket');
  }
}

// ============================================================
// INICIALIZAÇÃO PÚBLICA
// ============================================================

async function iniciar() {
  if (sock) {
    log.warn('iniciar() chamado com socket já ativo — ignorado');
    return;
  }
  destruido = false;
  log.info('Iniciando serviço WhatsApp');
  sock = await criarSocket();
}

// Shutdown gracioso (ex: SIGTERM no Railway)
async function encerrar() {
  destruido = true;
  log.info('Encerrando serviço WhatsApp');
  await destruirSocketAtual();
}

// ============================================================
// FILA DE ENVIO POR NÚMERO
// (garante que mensagens para o mesmo número saem em ordem
//  e com cooldown mínimo entre elas)
// ============================================================

function enfileirarEnvio(numero, fn) {
  const chain = filasEnvio.get(numero) || Promise.resolve();
  const novaChain = chain
    .catch(() => {})
    .then(async () => {
      await fn();
      // Cooldown mínimo entre envios para o mesmo número
      await esperar(SEND_COOLDOWN_MS + jitter(0, 600));
    })
    .finally(() => {
      if (filasEnvio.get(numero) === novaChain) {
        filasEnvio.delete(numero);
      }
    });
  filasEnvio.set(numero, novaChain);
}

// ============================================================
// ENVIO HUMANIZADO
// ============================================================

/**
 * Envia UMA mensagem de texto com typing indicator e delay proporcional.
 *
 * @param {string} numero  - JID do WhatsApp
 * @param {string} texto   - Texto a enviar
 * @param {object} opts
 * @param {number} opts.delayMin - delay mínimo de digitação (ms)
 * @param {number} opts.delayMax - delay máximo de digitação (ms)
 */
async function enviarMensagem(numero, texto, { delayMin = 2000, delayMax = 7000 } = {}) {
  if (!sock) throw new Error('[whatsapp] Socket não inicializado');

  return new Promise((resolve, reject) => {
    enfileirarEnvio(numero, async () => {
      try {
        // 1. Sinaliza que está digitando
        await sock.sendPresenceUpdate('composing', numero);

        // 2. Aguarda tempo proporcional ao texto (simula digitação humana)
        const delay = delayDigitacao(texto, { min: delayMin, max: delayMax });
        await esperar(delay);

        // 3. Envia
        await sock.sendMessage(numero, { text: texto });

        // 4. Para de digitar
        await sock.sendPresenceUpdate('paused', numero);

        log.info({ numero, chars: texto.length, delayMs: delay }, 'Mensagem enviada');
        resolve();
      } catch (err) {
        log.error({ numero, err: err.message }, 'Erro ao enviar mensagem');
        try { await sock.sendPresenceUpdate('paused', numero); } catch (_) {}
        reject(err);
      }
    });
  });
}

/**
 * Envia uma sequência de mensagens em ordem, com delay inicial humanizado.
 * Cada parte simula uma mensagem separada (como humano digitando em blocos).
 *
 * @param {string}   numero - JID do WhatsApp
 * @param {string[]} partes - Array de textos a enviar em sequência
 */
async function enviarSequencia(numero, partes) {
  if (!partes.length) return;

  // Delay inicial antes de começar a sequência
  await esperar(jitter(1200, 2500));

  for (const parte of partes) {
    if (!parte.trim()) continue;
    await enviarMensagem(numero, parte.trim());
    // Pausa entre partes da mesma sequência (menor que entre mensagens distintas)
    await esperar(jitter(600, 1400));
  }
}

/**
 * Envia mensagem de texto simples sem humanização.
 * Use apenas para mensagens internas / de sistema.
 */
async function enviarRaw(numero, texto) {
  if (!sock) throw new Error('[whatsapp] Socket não inicializado');
  return sock.sendMessage(numero, { text: texto });
}

// ============================================================
// UTILITÁRIOS PÚBLICOS
// ============================================================

function estaConectado() {
  return !!sock && !destruido;
}

function getSock() {
  return sock;
}

// ============================================================
// EXPORTS
// ============================================================
module.exports = {
  // Ciclo de vida
  iniciar,
  encerrar,
  estaConectado,
  getSock,

  // Eventos
  on:  (...args) => emitter.on(...args),
  off: (...args) => emitter.off(...args),
  once:(...args) => emitter.once(...args),

  // Envio
  enviarMensagem,
  enviarSequencia,
  enviarRaw,
};
