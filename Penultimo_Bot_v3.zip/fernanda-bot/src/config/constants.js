'use strict';

// ============================================================
// constants.js — Constantes globais do sistema
//
// FILOSOFIA:
//   Centralizar aqui todos os números e limites que controlam
//   o comportamento do bot. Nada de magic numbers espalhados.
//   Se precisar ajustar um limite, muda aqui — afeta tudo.
//
// ORGANIZAÇÃO:
//   - FUNIL         → estados, limites de etapa, scores
//   - ANTI_SPAM     → rate limiting, proteção anti-ban
//   - CLAUDE        → tokens, temperatura, retry
//   - WHATSAPP      → reconexão, envio, QR
//   - QUEUE         → fila de processamento
//   - DEBOUNCE      → agrupamento de mensagens
//   - FOLLOWUP      → scheduler, tentativas
//   - TIMEOUTS      → tempos gerais do sistema
// ============================================================

// ============================================================
// FUNIL DE CONVERSÃO
// ============================================================

const FUNIL = {
  // Etapas válidas do funil (ordem do fluxo)
  ETAPAS: ['inicio', 'conexao', 'descoberta', 'dor', 'apresentacao', 'prova', 'fechamento', 'followup', 'pausado'],

  // Máximo de mensagens da Fernanda por etapa antes de forçar avanço
  LIMITE_MSGS_POR_ETAPA: {
    inicio:        3,
    conexao:       4,
    descoberta:    5,
    dor:           4,
    apresentacao:  5,
    prova:         4,
    fechamento:    5,
    followup:      3,
    pausado:       0,
  },

  // Tempo mínimo (segundos) em uma etapa antes de poder avançar
  // Impede CTA precoce — a conversa precisa respirar
  TEMPO_MINIMO_ETAPA_S: {
    inicio:        0,
    conexao:       30,
    descoberta:    60,
    dor:           20,
    apresentacao:  45,
    prova:         30,
    fechamento:    0,
    followup:      0,
    pausado:       0,
  },

  // Scores mínimos para transições críticas
  SCORE_MINIMO_APRESENTACAO: 25,
  SCORE_MINIMO_FECHAMENTO:   45,
  SCORE_COMPRA_GATILHO:      60,  // dispara fechamento direto

  // Limite absoluto de mensagens da Fernanda por conversa
  MAX_MSGS_CONVERSA: 35,

  // Tempo sem resposta para considerar abandono
  TEMPO_ABANDONO_MS: 6 * 60 * 60 * 1000, // 6 horas
};

// ============================================================
// ANTI-SPAM / PROTEÇÃO ANTI-BAN
// ============================================================

const ANTI_SPAM = {
  // Máximo de mensagens enviadas pela Fernanda por número por hora
  MAX_MSGS_POR_HORA: 15,

  // Janela de contagem do rate limit
  JANELA_MS: 60 * 60 * 1000, // 1 hora

  // Máximo de vezes que o link de pagamento pode ser enviado por conversa
  MAX_LINKS_POR_CONVERSA: 2,
};

// ============================================================
// INTEGRAÇÃO COM CLAUDE API
// ============================================================

const CLAUDE = {
  // Modelo a usar (sempre Sonnet para custo/qualidade)
  MODEL: 'claude-sonnet-4-20250514',

  // Versão da API
  API_VERSION: '2023-06-01',

  // URL da API
  API_URL: 'https://api.anthropic.com/v1/messages',

  // Máximo de tokens na resposta — Fernanda não faz textão
  MAX_TOKENS_RESPOSTA: 400,

  // Budget de tokens para o histórico enviado na chamada
  MAX_TOKENS_HISTORICO: 3_000,

  // Limite de caracteres do output após sanitização
  MAX_CHARS_RESPOSTA: 800,

  // Mínimo de caracteres para uma resposta ser considerada válida
  MIN_CHARS_RESPOSTA: 8,

  // Máximo de partes em que uma resposta pode ser dividida
  MAX_PARTES_QUEBRA: 4,

  // Separador usado no prompt para quebrar mensagens no estilo WhatsApp
  SEPARADOR_QUEBRA: '|||QUEBRA|||',

  // Temperatura base — criativa mas controlada
  TEMPERATURA_BASE: 0.85,

  // Timeout hard da requisição HTTP
  TIMEOUT_MS: 28_000, // 28s — abaixo do limite do Railway (30s)

  // Retry
  MAX_TENTATIVAS:   3,
  BACKOFF_BASE_MS:  1_500,
  BACKOFF_MAX_MS:   12_000,
  BACKOFF_JITTER_MS: 800,

  // Cache leve para evitar chamadas duplicadas (race condition no debounce)
  CACHE_TTL_MS: 8_000,

  // Detecção de loop conversacional
  JANELA_LOOP_MSGS:   6,     // últimas N respostas da Fernanda a analisar
  SIMILARIDADE_LOOP:  0.82,  // % de bigramas em comum = loop
};

// ============================================================
// WHATSAPP / BAILEYS
// ============================================================

const WHATSAPP = {
  // Diretório de sessão (sobreponível via env AUTH_DIR)
  AUTH_DIR: process.env.AUTH_DIR || 'auth_info',

  // Backoff exponencial de reconexão
  BACKOFF_BASE_MS:   2_000,
  BACKOFF_MAX_MS:    120_000, // 2 minutos
  BACKOFF_JITTER_MS: 3_000,

  // Proteção contra reconnect storm
  STORM_MAX_FALHAS: 5,
  STORM_JANELA_MS:  60_000, // 1 minuto

  // QR expira sem scan após esse tempo
  QR_TIMEOUT_MS: 60_000,

  // Gap mínimo entre envios consecutivos para o mesmo número
  SEND_COOLDOWN_MS: 1_200,

  // Delay de digitação (simula humano digitando)
  TYPING_MIN_MS: 2_000,
  TYPING_MAX_MS: 7_000,
};

// ============================================================
// FILA DE PROCESSAMENTO (queue.js)
// ============================================================

const QUEUE = {
  // Timeout por tarefa — maior que o timeout do Claude
  TIMEOUT_TAREFA_MS: 45_000,

  // Máximo de mensagens enfileiradas por usuário (proteção anti-flood)
  MAX_FILA_POR_USUARIO: 10,
};

// ============================================================
// DEBOUNCE (agrupador de mensagens rápidas)
// ============================================================

const DEBOUNCE = {
  // Espera esse tempo de silêncio antes de processar
  JANELA_MS: 2_000,

  // Mesmo digitando, processa após esse tempo máximo
  JANELA_MAX_MS: 8_000,
};

// ============================================================
// FOLLOW-UP SCHEDULER
// ============================================================

const FOLLOWUP = {
  // Máximo de tentativas de follow-up antes de pausar o lead
  MAX_TENTATIVAS: 2,

  // Intervalo entre execuções do scheduler
  INTERVALO_MS: 30 * 60 * 1000, // 30 minutos

  // Lead inativo há mais de X minutos é elegível para follow-up
  MINUTOS_INATIVO: 120, // 2 horas

  // Delay entre envio de follow-ups consecutivos (anti-spam)
  DELAY_ENTRE_LEADS_MS: 2_000,
};

// ============================================================
// EXPORTS
// ============================================================

module.exports = {
  FUNIL,
  ANTI_SPAM,
  CLAUDE,
  WHATSAPP,
  FOLLOWUP,
  QUEUE,
  DEBOUNCE,
};
