'use strict';

// ============================================================
// env.js — Validação e exportação de variáveis de ambiente
//
// RESPONSABILIDADES:
//   - Validar presença de vars obrigatórias na inicialização
//   - Falhar RÁPIDO com mensagem clara se algo estiver faltando
//   - Exportar valores já processados (com defaults onde seguro)
//   - Nunca deixar o bot subir silenciosamente com config inválida
//
// USO:
//   const env = require('./config/env');
//   env.CLAUDE_API_KEY  → string
//   env.IS_PRODUCTION   → boolean
//
// IMPORTANTE:
//   Este módulo deve ser importado UMA VEZ no bootstrap (index.js),
//   antes de qualquer outro serviço. O require('dotenv').config()
//   deve ter sido chamado antes deste módulo.
// ============================================================

// ── Variáveis obrigatórias ────────────────────────────────────
// O bot não pode funcionar sem elas. Falha imediata com mensagem clara.
const OBRIGATORIAS = [
  'CLAUDE_API_KEY',
  'SUPABASE_URL',
  'SUPABASE_SERVICE_KEY',
  'LINK_PAGAMENTO',
];

const faltando = OBRIGATORIAS.filter(v => !process.env[v]?.trim());

if (faltando.length > 0) {
  console.error('\n❌ [env] Variáveis de ambiente obrigatórias não configuradas:');
  faltando.forEach(v => console.error(`   - ${v}`));
  console.error('\nConfigure essas variáveis no Railway (Settings → Variables) ou no .env local.\n');
  process.exit(1);
}

// ── Validações de formato ─────────────────────────────────────

// CLAUDE_API_KEY deve começar com 'sk-ant-'
if (!process.env.CLAUDE_API_KEY.startsWith('sk-ant-')) {
  console.error('\n❌ [env] CLAUDE_API_KEY inválida — deve começar com "sk-ant-"\n');
  process.exit(1);
}

// SUPABASE_URL deve ser uma URL válida
try {
  new URL(process.env.SUPABASE_URL);
} catch {
  console.error('\n❌ [env] SUPABASE_URL inválida — deve ser uma URL completa (ex: https://xxx.supabase.co)\n');
  process.exit(1);
}

// ── Exportações com defaults ──────────────────────────────────
module.exports = {
  // API Claude
  CLAUDE_API_KEY:      process.env.CLAUDE_API_KEY.trim(),

  // Supabase
  SUPABASE_URL:        process.env.SUPABASE_URL.trim(),
  SUPABASE_SERVICE_KEY: process.env.SUPABASE_SERVICE_KEY.trim(),

  // Produto
  LINK_PAGAMENTO:      process.env.LINK_PAGAMENTO.trim(),

  // Ambiente
  NODE_ENV:            process.env.NODE_ENV || 'production',
  IS_PRODUCTION:       process.env.NODE_ENV !== 'development',
  IS_DEVELOPMENT:      process.env.NODE_ENV === 'development',

  // Opcionais com defaults seguros
  LOG_LEVEL:           process.env.LOG_LEVEL || 'info',
  AUTH_DIR:            process.env.AUTH_DIR  || 'auth_info',
  PORT:                parseInt(process.env.PORT || '3000', 10),
};
