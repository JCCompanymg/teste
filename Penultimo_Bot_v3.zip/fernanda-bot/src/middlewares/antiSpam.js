'use strict';

// ============================================================
// antiSpam.js — Cooldown e rate limiting por número
//
// Controla quantas mensagens saem por número em uma janela
// de tempo, protegendo contra ban por comportamento anômalo.
// ============================================================

// Map<numero, { count, janela_inicio }>
const registros = new Map();

const MAX_MSGS_POR_HORA   = 15;
const JANELA_MS           = 60 * 60 * 1000; // 1 hora
const MAX_LINKS_POR_CONV  = 2;

// Contagem de links enviados por número
const linksEnviados = new Map();

/**
 * Retorna true se o número pode receber mais mensagens.
 * Deve ser chamado antes de enviarMensagem().
 */
function podeEnviar(numero) {
  const agora = Date.now();
  const reg   = registros.get(numero);

  if (!reg || agora - reg.janela_inicio > JANELA_MS) {
    registros.set(numero, { count: 0, janela_inicio: agora });
    return true;
  }

  return reg.count < MAX_MSGS_POR_HORA;
}

/**
 * Registra um envio. Chamar após enviarMensagem() confirmado.
 */
function registrarEnvio(numero) {
  const agora = Date.now();
  const reg   = registros.get(numero) || { count: 0, janela_inicio: agora };

  if (agora - reg.janela_inicio > JANELA_MS) {
    registros.set(numero, { count: 1, janela_inicio: agora });
  } else {
    reg.count++;
    registros.set(numero, reg);
  }
}

/**
 * Retorna true se ainda pode enviar link para este número.
 */
function podeEnviarLink(numero) {
  return (linksEnviados.get(numero) || 0) < MAX_LINKS_POR_CONV;
}

function registrarLinkEnviado(numero) {
  linksEnviados.set(numero, (linksEnviados.get(numero) || 0) + 1);
}

function statusAntiSpam(numero) {
  return {
    enviosNaJanela: registros.get(numero)?.count || 0,
    linksEnviados:  linksEnviados.get(numero) || 0,
    podeEnviar:     podeEnviar(numero),
    podeEnviarLink: podeEnviarLink(numero),
  };
}

module.exports = {
  podeEnviar,
  registrarEnvio,
  podeEnviarLink,
  registrarLinkEnviado,
  statusAntiSpam,
};
