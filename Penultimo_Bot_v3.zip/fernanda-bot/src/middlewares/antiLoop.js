'use strict';

// ============================================================
// antiLoop.js — Proteção contra reconnect storm
//
// Já implementado dentro de whatsapp.js via registrarFalha()
// e isReconnectStorm(). Este módulo expõe utilitários de
// diagnóstico que outros serviços podem consultar.
// ============================================================

// O estado real vive em whatsapp.js (falhasRecentes[]).
// Este arquivo existe para healthcheck e futura expansão.

let _getFalhas = () => [];

function registrarFonte(fn) {
  _getFalhas = fn;
}

function statusAntiLoop() {
  return {
    falhasRecentes: _getFalhas().length,
    emStorm: _getFalhas().length >= 5,
  };
}

module.exports = { registrarFonte, statusAntiLoop };
