'use strict';

function esperar(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// Delay proporcional ao texto, simulando digitação humana
// ~40 chars/s com jitter, limitado entre min e max
function delayDigitacao(texto, { min = 2000, max = 7000 } = {}) {
  const base = texto.length * 25 + Math.random() * 1500;
  return Math.max(min, Math.min(max, base));
}

// Jitter aleatório entre dois valores
function jitter(minMs, maxMs) {
  return minMs + Math.random() * (maxMs - minMs);
}

module.exports = { esperar, delayDigitacao, jitter };
