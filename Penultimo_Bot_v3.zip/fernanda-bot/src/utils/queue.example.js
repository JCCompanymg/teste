// ============================================================
// EXEMPLO DE INTEGRAÇÃO — queue.js + debounce.js
// Este arquivo é apenas ilustrativo. A integração real
// ficará em whatsapp.js quando for implementado.
// ============================================================
const { enfileirar, tamanhoFila } = require('./queue');
const { acumular } = require('./debounce');

// Simulação do handler de mensagens do Baileys:
function onMensagemRecebida(sock, numero, texto, lead) {
  // 1. O debounce acumula mensagens rápidas do mesmo usuário.
  //    Só chama o callback após 2s de silêncio (ou 8s no máximo).
  acumular(numero, texto, (num, textoAgrupado) => {

    // 2. O callback do debounce enfileira UMA tarefa por sequência.
    //    Mesmo que o usuário tenha mandado 4 mensagens, entra 1 na fila.
    enfileirar(
      num,
      () => processarMensagem(sock, num, textoAgrupado, lead),
      {
        onError: (n, err) => console.error(`[handler] Erro para ${n}:`, err.message),
        onTimeout: (n) => console.warn(`[handler] Timeout para ${n} — Claude demorou demais`),
      }
    );

    console.log(`[handler] Fila de ${num}: ${tamanhoFila(num)} tarefa(s) pendente(s)`);
  });
}

async function processarMensagem(sock, numero, texto, lead) {
  // lógica real virá do dispatcher.js
  console.log(`Processando para ${numero}: "${texto}"`);
}
