'use strict';

// ============================================================
// QUEUE — Fila serial por usuário
//
// Problema que resolve:
//   Usuário manda "oi" + "tudo bem?" + "queria saber do produto"
//   em 3 segundos. Sem fila, os três disparam processarMensagem()
//   em paralelo, cada um lê o histórico sem saber dos outros,
//   chama Claude 3x e grava 3 respostas descoordenadas.
//
// Como funciona:
//   Cada número tem sua própria Promise chain. Toda mensagem
//   nova é encadeada ao final da chain existente via .then().
//   O JavaScript executa uma por vez por usuário, na ordem de
//   chegada, independente de quantas chegam ao mesmo tempo.
//
// Garantias:
//   - Serial por usuário (sem paralelismo intra-usuário)
//   - Paralelo entre usuários diferentes (sem gargalo global)
//   - Auto-limpeza: a chain é removida do Map quando esvazia
//   - Timeout por tarefa: evita travar a fila se o Claude travar
//   - Erros isolados: falha em uma tarefa não cancela as próximas
// ============================================================

// Map<numero, Promise> — uma Promise chain por usuário
const filas = new Map();

// Quanto tempo (ms) uma tarefa pode levar antes de ser abortada
const TIMEOUT_TAREFA_MS = 45_000; // 45s (maior que o timeout do Claude)

// Quantas tarefas podem estar acumuladas por usuário antes de descartar
const MAX_FILA_POR_USUARIO = 10;

// Contador por usuário (para métricas e logs)
const contadores = new Map();

// ============================================================
// HELPERS
// ============================================================

function incrementarContador(numero) {
  contadores.set(numero, (contadores.get(numero) || 0) + 1);
}

function decrementarContador(numero) {
  const atual = (contadores.get(numero) || 1) - 1;
  if (atual <= 0) {
    contadores.delete(numero);
  } else {
    contadores.set(numero, atual);
  }
}

/**
 * Envolve uma tarefa em um timeout.
 * Se a tarefa não resolver em TIMEOUT_TAREFA_MS, rejeita com erro claro.
 */
function comTimeout(fn, numero) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`[queue] Timeout de ${TIMEOUT_TAREFA_MS}ms excedido para ${numero}`));
    }, TIMEOUT_TAREFA_MS);

    Promise.resolve()
      .then(() => fn())
      .then((resultado) => {
        clearTimeout(timer);
        resolve(resultado);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

// ============================================================
// API PÚBLICA
// ============================================================

/**
 * Enfileira uma tarefa para um número específico.
 *
 * @param {string}   numero  - JID do WhatsApp (ex: "5511999999999@s.whatsapp.net")
 * @param {Function} fn      - Função assíncrona a executar. Não recebe argumentos;
 *                             capture o que precisar no closure.
 * @param {object}   opts
 * @param {Function} opts.onError   - Callback de erro (numero, err). Opcional.
 * @param {Function} opts.onTimeout - Callback de timeout (numero). Opcional.
 *
 * @returns {void} — intencional. O caller não deve aguardar a fila;
 *                   ele apenas enfileira e segue.
 */
function enfileirar(numero, fn, { onError, onTimeout } = {}) {
  // Proteção contra fila gigante (ex: flood de mensagens)
  const tamanhoAtual = contadores.get(numero) || 0;
  if (tamanhoAtual >= MAX_FILA_POR_USUARIO) {
    const aviso = new Error(
      `[queue] Fila cheia para ${numero} (${tamanhoAtual}/${MAX_FILA_POR_USUARIO}). Mensagem descartada.`
    );
    if (onError) onError(numero, aviso);
    else console.warn(aviso.message);
    return;
  }

  incrementarContador(numero);

  // Obtém a chain atual ou cria uma Promise já resolvida como ponto de partida
  const chainAtual = filas.get(numero) || Promise.resolve();

  // Encadeia a nova tarefa ao final da chain existente.
  // O .catch(() => {}) ANTES do .then() garante que um erro em uma
  // tarefa anterior não cancele as próximas.
  const novaChain = chainAtual
    .catch(() => {}) // isola erros da tarefa anterior
    .then(async () => {
      try {
        await comTimeout(fn, numero);
      } catch (err) {
        const isTimeout = err.message.includes('Timeout');
        if (isTimeout && onTimeout) {
          onTimeout(numero, err);
        } else if (onError) {
          onError(numero, err);
        } else {
          console.error(`[queue] Erro não tratado para ${numero}:`, err.message);
        }
      } finally {
        decrementarContador(numero);
        // Auto-limpeza: se esta era a última tarefa, remove do Map
        // Compara por referência — só remove se nada foi enfileirado depois
        if (filas.get(numero) === novaChain) {
          filas.delete(numero);
        }
      }
    });

  filas.set(numero, novaChain);
}

/**
 * Retorna quantas tarefas estão pendentes para um número.
 * Útil para logs e para o debounce decidir se deve esperar.
 */
function tamanhoFila(numero) {
  return contadores.get(numero) || 0;
}

/**
 * Retorna true se há tarefas pendentes para o número.
 */
function estaProcessando(numero) {
  return filas.has(numero);
}

/**
 * Retorna um snapshot do estado atual de todas as filas.
 * Para métricas e healthcheck.
 */
function statusFilas() {
  const snapshot = {};
  for (const [numero, _] of filas) {
    snapshot[numero] = contadores.get(numero) || 0;
  }
  return snapshot;
}

// ============================================================
// EXPORTS
// ============================================================
module.exports = {
  enfileirar,
  tamanhoFila,
  estaProcessando,
  statusFilas,
};
