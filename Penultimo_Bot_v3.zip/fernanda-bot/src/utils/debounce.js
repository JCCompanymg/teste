'use strict';

// ============================================================
// DEBOUNCE — Agrupador de mensagens rápidas por usuário
//
// Problema que resolve:
//   Usuário digita em rajada:
//     [0ms]   "oi"
//     [800ms] "tudo bem?"
//     [1.2s]  "queria saber do kit"
//
//   Sem debounce, cada mensagem vai para a fila separada e o
//   Claude responde 3x, quebrando o ritmo da conversa.
//
//   Com debounce, o sistema espera JANELA_MS após a última
//   mensagem e entrega tudo de uma vez:
//     texto final: "oi\ntudo bem?\nqueria saber do kit"
//
// Como funciona:
//   Cada número tem um timer. Cada nova mensagem reinicia o
//   timer. Quando o timer dispara (silêncio por JANELA_MS),
//   chama o callback com todas as mensagens acumuladas.
//
// Integração com queue.js:
//   O debounce NÃO enfileira diretamente. Ele chama o callback
//   que o caller definiu — normalmente o caller é quem chama
//   enfileirar(). Assim os dois são desacoplados.
// ============================================================

// Tempo de silêncio necessário para considerar que o usuário terminou de digitar
const JANELA_MS = 2_000; // 2 segundos

// Tempo máximo de espera mesmo que o usuário continue digitando
// (evita segurar mensagem para sempre se o usuário é muito prolixo)
const JANELA_MAX_MS = 8_000; // 8 segundos

// Map<numero, { timer, timerMax, mensagens, iniciadoEm }>
const pendentes = new Map();

// ============================================================
// API PÚBLICA
// ============================================================

/**
 * Recebe uma mensagem e a acumula para o número.
 * Chama `callback(numero, mensagensAgrupadas)` quando o usuário
 * para de digitar por JANELA_MS ou após JANELA_MAX_MS.
 *
 * @param {string}   numero    - JID do WhatsApp
 * @param {string}   mensagem  - Texto da mensagem recebida
 * @param {Function} callback  - (numero: string, texto: string) => void
 *                               Chamado com o texto já concatenado.
 */
function acumular(numero, mensagem, callback) {
  const agora = Date.now();

  if (!pendentes.has(numero)) {
    // Primeira mensagem da sequência — configura estado inicial
    // e arma o timer máximo (não reinicia com novas mensagens)
    const timerMax = setTimeout(() => {
      _disparar(numero, callback);
    }, JANELA_MAX_MS);

    pendentes.set(numero, {
      timer: null,
      timerMax,
      mensagens: [],
      iniciadoEm: agora,
    });
  }

  const estado = pendentes.get(numero);
  estado.mensagens.push(mensagem.trim());

  // Reinicia o timer de silêncio a cada nova mensagem
  clearTimeout(estado.timer);
  estado.timer = setTimeout(() => {
    _disparar(numero, callback);
  }, JANELA_MS);
}

/**
 * Dispara o callback com as mensagens acumuladas e limpa o estado.
 * Privado — chamado pelos timers.
 */
function _disparar(numero, callback) {
  const estado = pendentes.get(numero);
  if (!estado) return;

  clearTimeout(estado.timer);
  clearTimeout(estado.timerMax);
  pendentes.delete(numero);

  const textoFinal = estado.mensagens.join('\n').trim();
  if (textoFinal) {
    callback(numero, textoFinal);
  }
}

/**
 * Cancela o debounce pendente para um número sem disparar o callback.
 * Útil quando o lead é pausado manualmente no meio de uma sequência.
 */
function cancelar(numero) {
  const estado = pendentes.get(numero);
  if (!estado) return;
  clearTimeout(estado.timer);
  clearTimeout(estado.timerMax);
  pendentes.delete(numero);
}

/**
 * Retorna true se há mensagens acumuladas aguardando para o número.
 */
function temPendente(numero) {
  return pendentes.has(numero);
}

/**
 * Snapshot do estado para métricas/healthcheck.
 */
function statusDebounce() {
  const snapshot = {};
  for (const [numero, estado] of pendentes) {
    snapshot[numero] = {
      mensagens: estado.mensagens.length,
      aguardandoHa: Date.now() - estado.iniciadoEm,
    };
  }
  return snapshot;
}

// ============================================================
// EXPORTS
// ============================================================
module.exports = {
  acumular,
  cancelar,
  temPendente,
  statusDebounce,
};
