# Fernanda Bot — Crescendo com a Palavra

Sistema de prompts modular para atendimento via WhatsApp.

---

## Estrutura

```
src/
  prompts/
    fernanda.js     ← ARQUIVO PRINCIPAL (este projeto)
  flows/
    dispatcher.js   ← Cérebro do funil (state machine)
  services/
    whatsapp.js
    claude.js
    database.js
    logger.js
  utils/
    debounce.js
    queue.js
  middlewares/
    antiSpam.js
index.js
```

---

## Arquitetura do fernanda.js

### `SYSTEM_BASE`
Identity core da Fernanda. Quem ela é, como escreve, o que nunca faz.
Vai como `system` em todas as chamadas à API Claude.

### `PROMPTS_POR_ETAPA`
Um prompt por estado da state machine:
| Estado | Objetivo |
|---|---|
| `inicio` | Acolhimento + primeira pergunta |
| `conexao` | Criar laço emocional |
| `descoberta` | Mapear a dor real |
| `dor` | Aprofundar consciência do problema |
| `apresentacao` | Revelar o kit naturalmente |
| `prova` | Histórias reais, eliminar dúvida |
| `fechamento` | Link + facilitar decisão |
| `followup` | Reativar sem pressão |
| `pausado` | Encerrar com dignidade |

### `AUXILIARES`
Fragmentos para situações especiais:
- `acolhimento_emocional` — quando ela expressa emoção negativa
- `curiosidade_prematura` — quando pergunta do produto antes da hora
- `resposta_monossilaba` — quando responde "ok", "sim", etc.
- `reset_conversa` — quando a conversa trava
- `resistencia` — quando ela está desconfiada

### `FALLBACKS`
Respostas de segurança:
- `generico` — situação não mapeada
- `fora_escopo` — assunto off-topic
- `resistencia` — lead resistente
- `silencio_longo` — sem resposta após followup
- `off_topic_pesado` — conteúdo inadequado

### `REGRAS_GLOBAIS`
Guardrails técnicos que se aplicam a TODOS os prompts:
- Anti-textão
- Anti-repetição
- Anti-loop
- Anti-robô
- Divisão de mensagens com `|||QUEBRA|||`

---

## Como usar

```js
const { instrucaoParaEtapa, SYSTEM_BASE } = require('./src/prompts/fernanda');

// Montar instrução para uma etapa
const instrucao = instrucaoParaEtapa('descoberta', contextoDoLead);

// Chamar a API
const resposta = await gerarResposta({
  systemPrompt:   SYSTEM_BASE,
  instrucaoEtapa: instrucao,
  historico,
  textoUsuario: texto,
});
```

---

## Variáveis de ambiente necessárias

```env
LINK_PAGAMENTO=pay.cakto.com.br/seu-produto
```

---

## Regras de ouro

1. **O dispatcher decide o fluxo. A Fernanda só fala.**
2. **Nunca mencione produto antes da etapa `apresentacao`.**
3. **O link só vai na etapa `fechamento` e só uma vez.**
4. **Resposta longa = resposta errada.**
5. **Se parece IA, reescreve como mãe.**
