-- ============================================================
-- schema_patch.sql — Colunas adicionadas pelo dispatcher v2
-- Execute no SQL Editor do Supabase UMA única vez.
-- O schema.sql original não precisa ser alterado.
-- ============================================================

-- Scores de intenção e engajamento
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score_interesse    INT NOT NULL DEFAULT 0;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score_emocional    INT NOT NULL DEFAULT 0;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS score_compra       INT NOT NULL DEFAULT 0;

-- Controle de mensagens por etapa e por conversa
ALTER TABLE leads ADD COLUMN IF NOT EXISTS msgs_etapa_atual     INT NOT NULL DEFAULT 0;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS total_msgs_fernanda  INT NOT NULL DEFAULT 0;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS total_msgs_mae       INT NOT NULL DEFAULT 0;

-- Timestamp de entrada na etapa atual (controle de tempo mínimo)
ALTER TABLE leads ADD COLUMN IF NOT EXISTS etapa_entrada_em TIMESTAMPTZ;

-- Índices auxiliares
CREATE INDEX IF NOT EXISTS leads_score_compra_idx     ON leads (score_compra);
CREATE INDEX IF NOT EXISTS leads_etapa_entrada_em_idx ON leads (etapa_entrada_em);
