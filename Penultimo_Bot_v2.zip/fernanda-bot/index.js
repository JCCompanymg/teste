'use strict';

// ============================================================
// index.js — Bootstrap do Bot Fernanda
//
// Responsabilidade única: ligar as peças.
// Não contém lógica de negócio.
// ============================================================

require('dotenv').config();

const { logger }     = require('./src/services/logger');
const whatsapp       = require('./src/services/whatsapp');
const { acumular }   = require('./src/utils/debounce');
const { enfileirar } = require('./src/utils/queue');
const dispatcher     = require('./src/flows/dispatcher');

// ── Inicializar o dispatcher (e o scheduler de follow-up) ────
dispatcher.inicializar();

// ── Eventos do WhatsApp ──────────────────────────────────────
whatsapp.on('mensagem', ({ numero, texto }) => {
  // Agrupa mensagens rápidas via debounce, depois enfileira
  acumular(numero, texto, (num, textoAgrupado) => {
    enfileirar(
      num,
      () => dispatcher.processarMensagem(num, textoAgrupado),
      {
        onError:   (n, err) => logger.error({ numero: n, err: err.message }, 'Erro na fila'),
        onTimeout: (n)      => logger.warn({ numero: n }, 'Timeout na fila'),
      }
    );
  });
});

whatsapp.on('conectado',    ()          => logger.info('WhatsApp pronto'));
whatsapp.on('desconectado', ({ motivo }) => logger.warn({ motivo }, 'WhatsApp desconectado'));
whatsapp.on('qr',           ()          => logger.info('QR disponível no terminal'));

// ── Shutdown gracioso ────────────────────────────────────────
async function shutdown(sinal) {
  logger.info({ sinal }, 'Encerrando...');
  const followup = require('./src/flows/followup');
  followup.parar();
  await whatsapp.encerrar();
  process.exit(0);
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));

// ── Erros não capturados ─────────────────────────────────────
process.on('uncaughtException',  (err) => logger.fatal({ err: err.message }, 'uncaughtException'));
process.on('unhandledRejection', (err) => logger.error({ err: String(err)  }, 'unhandledRejection'));

// ── Start ────────────────────────────────────────────────────
logger.info('Iniciando Bot Fernanda — Crescendo com a Palavra');
whatsapp.iniciar().catch(err => {
  logger.fatal({ err: err.message }, 'Falha fatal na inicialização');
  process.exit(1);
});
