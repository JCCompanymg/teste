'use strict';

// ============================================================
// flows/onboarding.js — Etapas: inicio → conexao
//
// Responsabilidade:
//   - Extrair idade do filho da primeira interação
//   - Detectar se é primeira mensagem ou retorno
//   - Gerar instrução específica para abertura de conversa
//
// NÃO faz:
//   - Chamar a API (isso é do dispatcher)
//   - Salvar no banco (isso é do dispatcher)
//   - Decidir avanço de etapa (isso é do dispatcher)
// ============================================================

// Padrões para extrair idade do filho do texto da mãe
const PADROES_IDADE = [
  /(\d+)\s*anos?/i,
  /(\d+)\s*meses?/i,
  /tem\s+(\d+)/i,
  /fez\s+(\d+)/i,
  /completou\s+(\d+)/i,
];

// Padrões para extrair nome do filho
const PADROES_NOME = [
  /(?:filho|filha|meu|minha)\s+(?:se\s+chama\s+|é\s+o\s+|é\s+a\s+)?([A-ZÁÉÍÓÚÃÕ][a-záéíóúãõ]+)/,
  /(?:o\s+|a\s+)([A-ZÁÉÍÓÚÃÕ][a-záéíóúãõ]+)\s+tem\s+\d+/,
  /chama\s+([A-ZÁÉÍÓÚÃÕ][a-záéíóúãõ]+)/i,
  /nome\s+(?:é\s+|dele\s+é\s+|dela\s+é\s+)?([A-ZÁÉÍÓÚÃÕ][a-záéíóúãõ]+)/i,
];

function extrairIdade(texto) {
  for (const padrao of PADROES_IDADE) {
    const match = texto.match(padrao);
    if (match) {
      const num = parseInt(match[1], 10);
      if (!isNaN(num)) {
        if (/mes/i.test(texto)) return `${num} meses`;
        return `${num} anos`;
      }
    }
  }
  return null;
}

function extrairNomeFilho(texto) {
  for (const padrao of PADROES_NOME) {
    const match = texto.match(padrao);
    if (match && match[1]) return match[1];
  }
  return null;
}

function isPrimeiraMensagem(texto, totalMsgsLead) {
  if (totalMsgsLead <= 1) return true;
  const SAUDACOES = /^(oi|olá|ola|bom dia|boa tarde|boa noite|hey)/i;
  return SAUDACOES.test(texto.trim());
}

function analisarMensagemOnboarding(texto, totalMsgsLead = 0) {
  const idade = extrairIdade(texto);
  return {
    idade_filho:      idade,
    nome_filho:       extrairNomeFilho(texto),
    e_primeira_msg:   isPrimeiraMensagem(texto, totalMsgsLead),
    pronto_para_avan: !!idade,
  };
}

module.exports = {
  analisarMensagemOnboarding,
  extrairIdade,
  extrairNomeFilho,
};
