'use strict';

// ============================================================
// flows/sales.js — Etapas: dor → apresentacao → prova → fechamento
//
// Responsabilidade:
//   - Mapear objeções para tratamentos
//   - Controlar envio de link (protegido por anti-spam)
//   - Decidir instrução de fechamento baseado no estado
//   - Detectar confirmação de compra
// ============================================================

// ── Objeções e como tratar ───────────────────────────────────

const TRATAMENTOS_OBJECAO = {
  preco: {
    instrucao: `Ela mencionou que o preço está pesado. 
Faça: apresente o parcelamento de forma natural ("dá pra parcelar, fica bem menos por vez"). Não explique demais. Não suplique. Valide que entende — você também passou por isso.
Não faça: não abaixe o preço, não ofereça desconto, não seja insistente.`,
  },
  indecisao: {
    instrucao: `Ela está em dúvida. 
Faça: mencione a garantia de 7 dias de forma casual — "se não gostar, é só falar que devolvo". Plante leveza na decisão.
Não faça: não pressione, não crie urgência falsa, não empilhe argumentos.`,
  },
  negacao: {
    instrucao: `Ela disse que não quer ou não precisa.
Faça: respeite completamente. Diga que está tudo bem, que foi bom conversar. Deixe uma porta aberta sem cobrar.
Não faça: não insista, não tente reverter, não seja chata.`,
  },
  terceiro: {
    instrucao: `Ela precisa consultar alguém (marido, mãe, etc.).
Faça: valide isso como normal — "claro, é bom decidir junto mesmo". Pergunte se quer que você mande o link pra ela mostrar depois.
Não faça: não diga "você mesma pode decidir", não desvalorize a opinião do parceiro.`,
  },
};

/**
 * Retorna a instrução específica para tratar uma objeção.
 * Se houver múltiplas, prioriza a mais relevante.
 */
function instrucaoParaObjecao(objecoes) {
  if (!objecoes || objecoes.length === 0) return null;

  // Prioridade: negacao > preco > terceiro > indecisao
  const PRIORIDADE = ['negacao', 'preco', 'terceiro', 'indecisao'];
  const principal  = PRIORIDADE.find(o => objecoes.includes(o)) || objecoes[0];

  return TRATAMENTOS_OBJECAO[principal]?.instrucao || null;
}

// ── Detecção de confirmação de compra ────────────────────────

const PADROES_CONFIRMACAO_COMPRA = [
  /comprei/i,
  /j[aá] (paguei|finalizei|fiz o pedido)/i,
  /deu certo/i,
  /recebi (o email|a confirmação)/i,
  /pedido (confirmado|feito)/i,
];

function detectarConfirmacaoCompra(texto) {
  return PADROES_CONFIRMACAO_COMPRA.some(p => p.test(texto));
}

// ── Controle de link ─────────────────────────────────────────

/**
 * Verifica se o link deve ser incluído na resposta.
 * Combina: etapa correta + anti-spam + score mínimo.
 */
function deveEnviarLink({ etapa, podeEnviarLink, scoreCompra, sinalCompra }) {
  if (etapa !== 'fechamento') return false;
  if (!podeEnviarLink) return false;
  if (scoreCompra < 20 && !sinalCompra) return false;
  return true;
}

/**
 * Monta um contexto de fechamento enriquecido com
 * informações sobre o link e condições de pagamento.
 */
function contextoFechamento(contexto, podeEnviarLink) {
  return {
    ...contexto,
    pode_enviar_link: podeEnviarLink,
    valor_avista:     'R$ 97',
    valor_parcelado:  'R$ 127',
    garantia_dias:    7,
  };
}

module.exports = {
  instrucaoParaObjecao,
  detectarConfirmacaoCompra,
  deveEnviarLink,
  contextoFechamento,
};
