'use strict';

// ============================================================
// flows/sales.js — Etapas: dor → apresentacao → prova → fechamento
//
// Responsabilidade:
//   - Mapear objeções para instruções de tratamento
//   - Controlar lógica de envio de link
//   - Detectar confirmação de compra
//   - Montar contexto enriquecido para fechamento
// ============================================================

const TRATAMENTOS_OBJECAO = {
  preco: `Ela mencionou que o preço está pesado.
Faça: apresente o parcelamento de forma natural ("dá pra parcelar, fica bem menos por vez"). Não explique demais. Não suplique. Valide que entende — você também passou por isso.
Não faça: não abaixe o preço, não ofereça desconto, não seja insistente.`,

  indecisao: `Ela está em dúvida.
Faça: mencione a garantia de 7 dias de forma casual — "se não gostar, é só falar que devolvo". Plante leveza na decisão.
Não faça: não pressione, não crie urgência falsa, não empilhe argumentos.`,

  negacao: `Ela disse que não quer ou não precisa.
Faça: respeite completamente. Diga que está tudo bem, que foi bom conversar. Deixe uma porta aberta sem cobrar.
Não faça: não insista, não tente reverter, não seja chata.`,

  terceiro: `Ela precisa consultar alguém (marido, mãe, etc.).
Faça: valide isso como normal — "claro, é bom decidir junto mesmo". Pergunte se quer que você mande o link pra ela mostrar depois.
Não faça: não diga "você mesma pode decidir", não desvalorize a opinião do parceiro.`,
};

const PADROES_CONFIRMACAO_COMPRA = [
  /comprei/i,
  /j[aá] (paguei|finalizei|fiz o pedido)/i,
  /deu certo/i,
  /recebi (o email|a confirmação)/i,
  /pedido (confirmado|feito)/i,
];

/**
 * Retorna a instrução de tratamento para a objeção principal.
 * Prioridade: negacao > preco > terceiro > indecisao
 */
function instrucaoParaObjecao(objecoes) {
  if (!objecoes || objecoes.length === 0) return null;
  const PRIORIDADE = ['negacao', 'preco', 'terceiro', 'indecisao'];
  const principal  = PRIORIDADE.find(o => objecoes.includes(o)) || objecoes[0];
  return TRATAMENTOS_OBJECAO[principal] || null;
}

/**
 * Detecta se a mãe confirmou que já comprou o produto.
 */
function detectarConfirmacaoCompra(texto) {
  return PADROES_CONFIRMACAO_COMPRA.some(p => p.test(texto));
}

/**
 * Decide se o link deve ser incluído na resposta.
 */
function deveEnviarLink({ etapa, podeEnviarLink, scoreCompra, sinalCompra }) {
  if (etapa !== 'fechamento') return false;
  if (!podeEnviarLink) return false;
  if (scoreCompra < 20 && !sinalCompra) return false;
  return true;
}

/**
 * Monta o contexto enriquecido para a etapa de fechamento.
 */
function contextoFechamento(contexto, podeEnviarLink) {
  return {
    ...contexto,
    pode_enviar_link: podeEnviarLink,
    valor_avista:     'R$ 97',
    valor_parcelado:  'R$ 127',
    garantia_dias:    7,
  };
}

module.exports = {
  instrucaoParaObjecao,
  detectarConfirmacaoCompra,
  deveEnviarLink,
  contextoFechamento,
};
