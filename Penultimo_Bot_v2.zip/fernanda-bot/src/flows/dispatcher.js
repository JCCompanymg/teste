'use strict';

// ============================================================
// dispatcher.js — Cérebro estratégico do sistema
//
// RESPONSABILIDADES:
//   - Controlar o estado do lead (etapa, scores, contadores)
//   - Decidir quando avançar, pausar ou fazer follow-up
//   - Montar a instrução certa para cada momento
//   - Chamar a IA apenas para escrever o texto
//   - Controlar envio via whatsapp.js
//   - Proteger contra loops, overtalking e CTA precoce
//
// REGRA FUNDAMENTAL:
//   A IA NÃO controla o fluxo. O dispatcher controla.
//   A IA apenas escreve, humaniza, improvisa texto.
// ============================================================

const { criarLogger }           = require('../services/logger');
const db                        = require('../services/database');
const claude                    = require('../services/claude');
const whatsapp                  = require('../services/whatsapp');
const { podeEnviar,
        registrarEnvio,
        podeEnviarLink,
        registrarLinkEnviado }  = require('../middlewares/antiSpam');
const { esperar,
        delayDigitacao }        = require('../utils/delays');
const { SYSTEM_BASE,
        construirInstrucao }    = require('../prompts/fernanda');
const { analisarMensagemOnboarding } = require('./onboarding');
const { analisarMensagem,
        avaliarProgressao }     = require('./discovery');
const { instrucaoParaObjecao,
        detectarConfirmacaoCompra,
        deveEnviarLink,
        contextoFechamento }    = require('./sales');
const followupScheduler         = require('./followup');
const { FUNIL }                 = require('../config/constants');

const log = criarLogger({ modulo: 'dispatcher' });

// ============================================================
// CONSTANTES LOCAIS
// ============================================================

const COOLDOWN_ENTRE_PARTES_MS = 1_200;
const ETAPAS = FUNIL.ETAPAS;

// ============================================================
// HELPERS DE ESTADO
// ============================================================

function indiceEtapa(etapa) {
  return ETAPAS.indexOf(etapa);
}

function proximaEtapa(etapaAtual) {
  const idx    = indiceEtapa(etapaAtual);
  const LIMITE = indiceEtapa('fechamento');
  if (idx < 0 || idx >= LIMITE) return etapaAtual;
  return ETAPAS[idx + 1];
}

function tempoMinimoRespeitado(lead) {
  const tempoMinS = FUNIL.TEMPO_MINIMO_ETAPA_S[lead.etapa] || 0;
  if (tempoMinS === 0) return true;
  const entrada = lead.etapa_entrada_em
    ? new Date(lead.etapa_entrada_em).getTime()
    : new Date(lead.criado_em).getTime();
  return (Date.now() - entrada) >= tempoMinS * 1000;
}

function limiteMsgAtingido(lead) {
  const limite = FUNIL.LIMITE_MSGS_POR_ETAPA[lead.etapa] ?? 99;
  return (lead.msgs_etapa_atual || 0) >= limite;
}

function limiteConversaAtingido(lead) {
  return (lead.total_msgs_fernanda || 0) >= FUNIL.MAX_MSGS_CONVERSA;
}

// ============================================================
// DETECÇÃO DE PISTAS NATURAIS
// ============================================================

async function detectarPistas(lead, texto) {
  const contextoAtual = await db.obterContexto(lead.id);
  const onboarding    = analisarMensagemOnboarding(texto, lead.total_msgs_mae || 0);
  const analise       = analisarMensagem(texto, contextoAtual);

  const novosContextos = { ...analise.novos_contextos };
  if (onboarding.nome_filho)  novosContextos.nome_filho  = onboarding.nome_filho;
  if (onboarding.idade_filho) novosContextos.idade_filho = onboarding.idade_filho;

  for (const [chave, valor] of Object.entries(novosContextos)) {
    try {
      await db.salvarContexto(lead.id, chave, valor);
    } catch (err) {
      log.warn({ chave, err: err.message }, 'Falha ao salvar contexto');
    }
  }

  const contextoAtualizado = { ...contextoAtual, ...novosContextos };
  return { contextoAtualizado, analise, onboarding };
}

// ============================================================
// MÁQUINA DE ESTADOS
// ============================================================

function decidirEtapa(lead, analise, progressao, onboarding) {
  const etapa = lead.etapa;

  if (analise.sinais_abandono) {
    return { novaEtapa: 'pausado', motivo: 'abandono_detectado' };
  }

  if (limiteConversaAtingido(lead)) {
    return { novaEtapa: 'pausado', motivo: 'limite_conversa_atingido' };
  }

  if (detectarConfirmacaoCompra(lead._ultimo_texto_mae || '')) {
    return { novaEtapa: 'pausado', motivo: 'compra_confirmada' };
  }

  if (progressao.deveAnteciparFechamento && indiceEtapa(etapa) < indiceEtapa('fechamento')) {
    return { novaEtapa: 'fechamento', motivo: 'sinal_compra_direta' };
  }

  switch (etapa) {
    case 'inicio':
      if (onboarding.pronto_para_avan || limiteMsgAtingido(lead)) {
        return { novaEtapa: 'conexao', motivo: 'idade_captada_ou_limite' };
      }
      break;

    case 'conexao':
      if (tempoMinimoRespeitado(lead) && limiteMsgAtingido(lead)) {
        return { novaEtapa: 'descoberta', motivo: 'conexao_estabelecida' };
      }
      break;

    case 'descoberta': {
      const temDor = progressao.scoreEmocional >= 10;
      if ((temDor && tempoMinimoRespeitado(lead)) || limiteMsgAtingido(lead)) {
        return { novaEtapa: 'dor', motivo: 'dor_identificada_ou_limite' };
      }
      break;
    }

    case 'dor':
      if (progressao.prontoPraApresentacao && tempoMinimoRespeitado(lead)) {
        return { novaEtapa: 'apresentacao', motivo: 'score_interesse_atingido' };
      }
      if (limiteMsgAtingido(lead)) {
        return { novaEtapa: 'apresentacao', motivo: 'limite_msgs_forcado' };
      }
      break;

    case 'apresentacao':
      if (progressao.prontoPraFechamento && tempoMinimoRespeitado(lead)) {
        return { novaEtapa: 'prova', motivo: 'interesse_confirmado' };
      }
      if (limiteMsgAtingido(lead)) {
        return { novaEtapa: 'prova', motivo: 'limite_msgs_forcado' };
      }
      break;

    case 'prova':
      if ((progressao.scoreCompra >= 30 && tempoMinimoRespeitado(lead)) || limiteMsgAtingido(lead)) {
        return { novaEtapa: 'fechamento', motivo: 'prova_concluida' };
      }
      break;

    case 'fechamento':
      break;

    case 'followup':
      return { novaEtapa: 'fechamento', motivo: 'respondeu_followup' };

    default:
      break;
  }

  return { novaEtapa: etapa, motivo: 'sem_mudanca' };
}

// ============================================================
// CONSTRUÇÃO DA INSTRUÇÃO
// ============================================================

function montarInstrucao(etapa, contexto, analise, lead) {
  if (analise.objecoes.length > 0 && ['apresentacao', 'prova', 'fechamento'].includes(etapa)) {
    const instrObjecao = instrucaoParaObjecao(analise.objecoes);
    if (instrObjecao) return instrObjecao;
  }

  const ctx = etapa === 'fechamento'
    ? contextoFechamento(contexto, podeEnviarLink(lead.numero))
    : contexto;

  return construirInstrucao(etapa, ctx, {
    tentativa_followup: lead.tentativas_followup || 1,
  });
}

// ============================================================
// ENVIO DE MENSAGEM (com typing + anti-spam)
// ============================================================

async function enviarResposta(numero, partes, isLink = false) {
  for (let i = 0; i < partes.length; i++) {
    const parte = partes[i];

    if (!podeEnviar(numero)) {
      log.warn({ numero }, 'Anti-spam: limite de envios atingido — abortando');
      break;
    }

    const ms = delayDigitacao(parte);
    await whatsapp.enviarDigitando(numero, ms);
    await esperar(ms);
    await whatsapp.enviarMensagem(numero, parte);
    registrarEnvio(numero);

    if (i < partes.length - 1) {
      await esperar(COOLDOWN_ENTRE_PARTES_MS);
    }
  }

  if (isLink) {
    registrarLinkEnviado(numero);
  }
}

// ============================================================
// ATUALIZAÇÃO DO LEAD NO BANCO
// ============================================================

async function persistirEstado(lead, novaEtapa, analise, progressao) {
  const mudouEtapa = novaEtapa !== lead.etapa;

  const campos = {
    etapa:               novaEtapa,
    score_interesse:     Math.min(100, Math.max(0, (lead.score_interesse || 0) + analise.delta_score_interesse)),
    score_emocional:     Math.min(100, Math.max(0, (lead.score_emocional || 0) + analise.delta_score_emocional)),
    score_compra:        Math.min(100, Math.max(0, (lead.score_compra    || 0) + analise.delta_score_compra)),
    msgs_etapa_atual:    mudouEtapa ? 1 : (lead.msgs_etapa_atual || 0) + 1,
    total_msgs_fernanda: (lead.total_msgs_fernanda || 0) + 1,
    total_msgs_mae:      (lead.total_msgs_mae      || 0) + 1,
    ultima_mensagem:     new Date().toISOString(),
    pausado:             novaEtapa === 'pausado',
  };

  if (mudouEtapa) {
    campos.etapa_entrada_em = new Date().toISOString();
  }

  return db.atualizarLead(lead.numero, campos);
}

// ============================================================
// PROCESSADOR DE FOLLOW-UP
// ============================================================

async function processarFollowup(lead) {
  log.info({ numero: lead.numero, tentativa: (lead.tentativas_followup || 0) + 1 }, 'Processando follow-up');

  const tentativa = (lead.tentativas_followup || 0) + 1;

  if (tentativa > FUNIL.LIMITE_MSGS_POR_ETAPA.followup) {
    await db.atualizarLead(lead.numero, {
      pausado:      true,
      etapa:        'pausado',
      atualizado_em: new Date().toISOString(),
    });
    log.info({ numero: lead.numero }, 'Lead pausado após esgotar follow-ups');
    return;
  }

  if (!podeEnviar(lead.numero)) {
    log.warn({ numero: lead.numero }, 'Anti-spam bloqueou follow-up');
    return;
  }

  const contexto  = await db.obterContexto(lead.id);
  const historico = await db.obterHistorico(lead.id, 6);
  const instrucao = construirInstrucao('followup', contexto, { tentativa_followup: tentativa });

  const { partes } = await claude.gerarResposta({
    numero:            lead.numero,
    textoUsuario:      '[SISTEMA: envie o follow-up agora, sem mensagem nova da mãe]',
    historico,
    contexto,
    etapa:             'followup',
    instrucaoEtapa:    instrucao,
    systemPrompt:      SYSTEM_BASE,
    historicoFernanda: historico.filter(h => h.role === 'assistant').map(h => h.content),
  });

  await enviarResposta(lead.numero, partes);

  const textoFinal = partes.join(' ');
  await db.inserirHistorico(lead.id, 'assistant', textoFinal);

  await db.atualizarLead(lead.numero, {
    tentativas_followup: tentativa,
    etapa:               'followup',
    ultima_mensagem:     new Date().toISOString(),
  });

  await db.registrarEvento(lead.id, 'followup_enviado', { tentativa });
}

// ============================================================
// PROCESSADOR PRINCIPAL — entrada de mensagem
// ============================================================

/**
 * Processa uma mensagem recebida de uma mãe.
 * Ponto de entrada chamado pelo index.js via fila.
 *
 * @param {string} numero - JID do WhatsApp
 * @param {string} texto  - Mensagem agrupada pelo debounce
 */
async function processarMensagem(numero, texto) {
  log.info({ numero, chars: texto.length }, 'Processando mensagem');

  // ── 1. Carregar lead ──────────────────────────────────────
  let lead;
  try {
    lead = await db.obterOuCriarLead(numero);
  } catch (err) {
    log.error({ numero, err: err.message }, 'Falha ao obter lead — abortando');
    return;
  }

  lead._ultimo_texto_mae = texto;

  // ── 2. Lead pausado — silêncio ────────────────────────────
  if (lead.pausado || lead.etapa === 'pausado') {
    log.info({ numero }, 'Lead pausado — ignorando mensagem');
    return;
  }

  // ── 3. Salvar mensagem da mãe no histórico ────────────────
  try {
    await db.inserirHistorico(lead.id, 'user', texto);
  } catch (err) {
    log.warn({ numero, err: err.message }, 'Falha ao salvar histórico da mãe');
  }

  // ── 4. Detectar pistas ────────────────────────────────────
  const { contextoAtualizado, analise, onboarding } = await detectarPistas(lead, texto);

  // ── 5. Avaliar scores ─────────────────────────────────────
  const progressao = avaliarProgressao(lead, analise);

  // ── 6. Decidir nova etapa ─────────────────────────────────
  const { novaEtapa, motivo } = decidirEtapa(lead, analise, progressao, onboarding);

  if (novaEtapa !== lead.etapa) {
    log.info({ numero, de: lead.etapa, para: novaEtapa, motivo }, 'Transição de etapa');
    await db.registrarEvento(lead.id, 'etapa_mudou', { de: lead.etapa, para: novaEtapa, motivo });
  }

  // ── 7. Abandono — pausa sem resposta ──────────────────────
  if (novaEtapa === 'pausado') {
    await db.atualizarLead(numero, {
      etapa:        'pausado',
      pausado:      true,
      atualizado_em: new Date().toISOString(),
    });
    log.info({ numero, motivo }, 'Lead pausado');
    return;
  }

  // ── 8. Carregar histórico para o Claude ───────────────────
  let historico = [];
  try {
    historico = await db.obterHistorico(lead.id, 12);
  } catch (err) {
    log.warn({ numero, err: err.message }, 'Falha ao carregar histórico');
  }

  const historicoFernanda = historico
    .filter(h => h.role === 'assistant')
    .map(h => h.content);

  // ── 9. Montar instrução de etapa ──────────────────────────
  const instrucao = montarInstrucao(novaEtapa, contextoAtualizado, analise, lead);

  // ── 10. Gerar resposta via Claude ─────────────────────────
  let partes = [];
  try {
    const resultado = await claude.gerarResposta({
      numero,
      textoUsuario:      texto,
      historico,
      contexto:          contextoAtualizado,
      etapa:             novaEtapa,
      instrucaoEtapa:    instrucao,
      systemPrompt:      SYSTEM_BASE,
      historicoFernanda,
    });
    partes = resultado.partes;

    log.info({
      numero,
      etapa:    novaEtapa,
      partes:   partes.length,
      tokens:   resultado.tokens,
      latencia: resultado.latencia,
      cached:   resultado.cached,
    }, 'Resposta gerada');

  } catch (err) {
    log.error({ numero, err: err.message }, 'Falha crítica ao gerar resposta');
    return;
  }

  if (!partes || partes.length === 0) {
    log.warn({ numero }, 'Nenhuma parte para enviar');
    return;
  }

  // ── 11. Verificar envio de link ───────────────────────────
  const incluirLink = deveEnviarLink({
    etapa:          novaEtapa,
    podeEnviarLink: podeEnviarLink(numero),
    scoreCompra:    progressao.scoreCompra,
    sinalCompra:    analise.sinal_compra_direta,
  });

  // ── 12. Enviar resposta ───────────────────────────────────
  await enviarResposta(numero, partes, incluirLink);

  // ── 13. Salvar resposta no histórico ──────────────────────
  const textoFinal = partes.join(' ');
  try {
    await db.inserirHistorico(lead.id, 'assistant', textoFinal);
  } catch (err) {
    log.warn({ numero, err: err.message }, 'Falha ao salvar resposta no histórico');
  }

  // ── 14. Persistir estado ──────────────────────────────────
  try {
    lead = await persistirEstado(lead, novaEtapa, analise, progressao);
  } catch (err) {
    log.error({ numero, err: err.message }, 'Falha ao persistir estado');
  }

  // ── 15. Registrar evento de link ──────────────────────────
  if (incluirLink) {
    await db.registrarEvento(lead.id, 'link_enviado', {
      etapa:        novaEtapa,
      score_compra: progressao.scoreCompra,
    }).catch(err => log.warn({ err: err.message }, 'Falha ao registrar evento link'));
  }

  log.info({ numero, etapa: novaEtapa }, 'Mensagem processada com sucesso');
}

// ============================================================
// INICIALIZAÇÃO
// ============================================================

function inicializar() {
  followupScheduler.registrarProcessador(processarFollowup);
  followupScheduler.iniciar();
  log.info('Dispatcher inicializado');
}

// ============================================================
// EXPORTS
// ============================================================

module.exports = {
  processarMensagem,
  processarFollowup,
  inicializar,
};
