'use strict';

// ============================================================
// dispatcher.js — Cérebro estratégico do sistema
//
// RESPONSABILIDADES:
//   - Controlar o estado do lead (etapa, scores, contadores)
//   - Decidir quando avançar, pausar ou fazer follow-up
//   - Montar a instrução certa para cada momento
//   - Chamar a IA apenas para escrever o texto
//   - Controlar envio via whatsapp.js
//   - Proteger contra loops, overtalking e CTA precoce
//
// REGRA FUNDAMENTAL:
//   A IA NÃO controla o fluxo. O dispatcher controla.
//   A IA apenas escreve, humaniza, improvisa texto.
// ============================================================

const { criarLogger }           = require('../services/logger');
const db                        = require('../services/database');
const claude                    = require('../services/claude');
const whatsapp                  = require('../services/whatsapp');
const { podeEnviar,
        registrarEnvio,
        podeEnviarLink,
        registrarLinkEnviado }  = require('../middlewares/antiSpam');
const { esperar, delayDigitacao } = require('../utils/delays');
const { SYSTEM_BASE,
        construirInstrucao }    = require('../prompts/fernanda');
const { analisarMensagemOnboarding } = require('./onboarding');
const { analisarMensagem,
        avaliarProgressao }     = require('./discovery');
const { instrucaoParaObjecao,
        detectarConfirmacaoCompra,
        deveEnviarLink,
        contextoFechamento }    = require('./sales');
const followupScheduler         = require('./followup');
const { FUNIL, ANTI_SPAM }      = require('../config/constants');

const log = criarLogger({ modulo: 'dispatcher' });

// ============================================================
// CONSTANTES LOCAIS
// ============================================================

// Tempo mínimo em ms entre duas mensagens enviadas ao mesmo número
const COOLDOWN_ENTRE_PARTES_MS = 1_200;

// Etapas em ordem — usadas para calcular avanço
const ETAPAS = FUNIL.ETAPAS;

// ============================================================
// HELPERS DE ESTADO
// ============================================================

/**
 * Retorna o índice da etapa na sequência do funil.
 */
function indiceEtapa(etapa) {
  return ETAPAS.indexOf(etapa);
}

/**
 * Retorna a próxima etapa do funil, respeitando os limites.
 * Nunca avança além de 'fechamento' automaticamente.
 * 'pausado' e 'followup' são estados especiais.
 */
function proximaEtapa(etapaAtual) {
  const idx = indiceEtapa(etapaAtual);
  const LIMITE = indiceEtapa('fechamento');
  if (idx < 0 || idx >= LIMITE) return etapaAtual;
  return ETAPAS[idx + 1];
}

/**
 * Verifica se o tempo mínimo na etapa foi respeitado.
 */
function tempoMinimoRespeitado(lead) {
  const tempoMinS = FUNIL.TEMPO_MINIMO_ETAPA_S[lead.etapa] || 0;
  if (tempoMinS === 0) return true;

  const entrada = lead.etapa_entrada_em
    ? new Date(lead.etapa_entrada_em).getTime()
    : new Date(lead.criado_em).getTime();

  return (Date.now() - entrada) >= tempoMinS * 1000;
}

/**
 * Verifica se o limite de mensagens da etapa foi atingido.
 */
function limiteMsgAtingido(lead) {
  const limite = FUNIL.LIMITE_MSGS_POR_ETAPA[lead.etapa] ?? 99;
  return (lead.msgs_etapa_atual || 0) >= limite;
}

/**
 * Verifica se o limite absoluto de mensagens da conversa foi atingido.
 */
function limiteConversaAtingido(lead) {
  return (lead.total_msgs_fernanda || 0) >= FUNIL.MAX_MSGS_CONVERSA;
}

// ============================================================
// DETECÇÃO DE PISTAS NATURAIS
// ============================================================

/**
 * Extrai pistas do texto e atualiza o contexto do lead.
 * Retorna { contextoNovo, analise }.
 */
async function detectarPistas(lead, texto) {
  const contextoAtual = await db.obterContexto(lead.id);

  // Análise de onboarding (nome/idade do filho)
  const onboarding = analisarMensagemOnboarding(texto, lead.total_msgs_mae || 0);

  // Análise de dor, interesse e compra
  const analise = analisarMensagem(texto, contextoAtual);

  // Salva novos contextos detectados
  const novosContextos = { ...analise.novos_contextos };
  if (onboarding.nome_filho) novosContextos.nome_filho   = onboarding.nome_filho;
  if (onboarding.idade_filho) novosContextos.idade_filho = onboarding.idade_filho;

  for (const [chave, valor] of Object.entries(novosContextos)) {
    try {
      await db.salvarContexto(lead.id, chave, valor);
    } catch (err) {
      log.warn({ chave, err: err.message }, 'Falha ao salvar contexto');
    }
  }

  const contextoAtualizado = { ...contextoAtual, ...novosContextos };
  return { contextoAtualizado, analise, onboarding };
}

// ============================================================
// MÁQUINA DE ESTADOS — DECISÃO DE ETAPA
// ============================================================

/**
 * Decide a próxima etapa do funil com base no estado atual e na análise.
 *
 * Retorna:
 *   { novaEtapa, motivo }
 *
 * Se novaEtapa === etapa atual: mantém.
 * Se diferente: avança (ou pausa).
 */
function decidirEtapa(lead, analise, progressao, onboarding) {
  const etapa = lead.etapa;

  // Abandono explícito → pausa
  if (analise.sinais_abandono) {
    return { novaEtapa: 'pausado', motivo: 'abandono_detectado' };
  }

  // Limite absoluto da conversa → pausa
  if (limiteConversaAtingido(lead)) {
    return { novaEtapa: 'pausado', motivo: 'limite_conversa_atingido' };
  }

  // Confirmação de compra → pausa (conversa encerrada com sucesso)
  if (detectarConfirmacaoCompra(lead._ultimo_texto_mae || '')) {
    return { novaEtapa: 'pausado', motivo: 'compra_confirmada' };
  }

  // Sinal de compra direta — pula direto pro fechamento
  if (progressao.deveAnteciparFechamento && indiceEtapa(etapa) < indiceEtapa('fechamento')) {
    return { novaEtapa: 'fechamento', motivo: 'sinal_compra_direta' };
  }

  // Lógica por etapa
  switch (etapa) {
    case 'inicio': {
      // Avança para conexao quando tem a idade do filho OU atingiu limite de msgs
      if (onboarding.pronto_para_avan || limiteMsgAtingido(lead)) {
        return { novaEtapa: 'conexao', motivo: 'idade_captada_ou_limite' };
      }
      break;
    }

    case 'conexao': {
      // Avança para descoberta quando tempo mínimo respeitado + limite msgs
      if (tempoMinimoRespeitado(lead) && limiteMsgAtingido(lead)) {
        return { novaEtapa: 'descoberta', motivo: 'conexao_estabelecida' };
      }
      break;
    }

    case 'descoberta': {
      // Avança para dor quando detectou dor ou atingiu limite
      const temDor = progressao.scoreEmocional >= 10;
      if ((temDor && tempoMinimoRespeitado(lead)) || limiteMsgAtingido(lead)) {
        return { novaEtapa: 'dor', motivo: 'dor_identificada_ou_limite' };
      }
      break;
    }

    case 'dor': {
      // Avança para apresentacao quando score de interesse está pronto
      if (progressao.prontoPraApresentacao && tempoMinimoRespeitado(lead)) {
        return { novaEtapa: 'apresentacao', motivo: 'score_interesse_atingido' };
      }
      if (limiteMsgAtingido(lead)) {
        // Força apresentação mesmo sem score ideal (já falou demais)
        return { novaEtapa: 'apresentacao', motivo: 'limite_msgs_forcado' };
      }
      break;
    }

    case 'apresentacao': {
      // Avança para prova quando score de interesse alto
      if (progressao.prontoPraFechamento && tempoMinimoRespeitado(lead)) {
        return { novaEtapa: 'prova', motivo: 'interesse_confirmado' };
      }
      if (limiteMsgAtingido(lead)) {
        return { novaEtapa: 'prova', motivo: 'limite_msgs_forcado' };
      }
      break;
    }

    case 'prova': {
      // Avança para fechamento quando score alto ou limite atingido
      if ((progressao.scoreCompra >= 30 && tempoMinimoRespeitado(lead)) || limiteMsgAtingido(lead)) {
        return { novaEtapa: 'fechamento', motivo: 'prova_concluida' };
      }
      break;
    }

    case 'fechamento': {
      // Fechamento: não avança mais. Só pausa se abandono.
      break;
    }

    case 'followup': {
      // Se ela respondeu, volta para a etapa de antes
      // (o dispatcher detecta isso pelo fato de ter recebido mensagem nova)
      return { novaEtapa: 'fechamento', motivo: 'respondeu_followup' };
    }

    default:
      break;
  }

  return { novaEtapa: etapa, motivo: 'sem_mudanca' };
}

// ============================================================
// CONSTRUÇÃO DA INSTRUÇÃO
// ============================================================

/**
 * Monta a instrução de etapa com base no estado atual.
 * Lida com objeções sobrepostas ao comportamento padrão da etapa.
 */
function montarInstrucao(etapa, contexto, analise, lead) {
  // Objeção ativa tem prioridade sobre instrução padrão de fechamento
  if (analise.objecoes.length > 0 && ['apresentacao', 'prova', 'fechamento'].includes(etapa)) {
    const instrObjecao = instrucaoParaObjecao(analise.objecoes);
    if (instrObjecao) return instrObjecao;
  }

  // Contexto enriquecido para fechamento
  const ctx = etapa === 'fechamento'
    ? contextoFechamento(contexto, podeEnviarLink(lead.numero))
    : contexto;

  return construirInstrucao(etapa, ctx, {
    tentativa_followup: lead.tentativas_followup || 1,
  });
}

// ============================================================
// ENVIO DE MENSAGEM (com typing + anti-spam)
// ============================================================

/**
 * Envia as partes da resposta com delays humanos entre elas.
 * Respeita anti-spam e registra cada envio.
 */
async function enviarResposta(numero, partes, isLink = false) {
  for (const parte of partes) {
    if (!podeEnviar(numero)) {
      log.warn({ numero }, 'Anti-spam: limite de envios atingido — abortando');
      break;
    }

    const ms = delayDigitacao(parte);
    await whatsapp.enviarDigitando(numero, ms);
    await esperar(ms);
    await whatsapp.enviarMensagem(numero, parte);
    registrarEnvio(numero);

    // Gap entre partes
    if (partes.indexOf(parte) < partes.length - 1) {
      await esperar(COOLDOWN_ENTRE_PARTES_MS);
    }
  }

  if (isLink) {
    registrarLinkEnviado(numero);
  }
}

// ============================================================
// ATUALIZAÇÃO DO LEAD NO BANCO
// ============================================================

/**
 * Persiste as mudanças de estado no banco após processar uma mensagem.
 */
async function persistirEstado(lead, novaEtapa, analise, progressao) {
  const mudouEtapa = novaEtapa !== lead.etapa;

  const campos = {
    etapa:                novaEtapa,
    score_interesse:      Math.min(100, Math.max(0, (lead.score_interesse || 0) + analise.delta_score_interesse)),
    score_emocional:      Math.min(100, Math.max(0, (lead.score_emocional || 0) + analise.delta_score_emocional)),
    score_compra:         Math.min(100, Math.max(0, (lead.score_compra    || 0) + analise.delta_score_compra)),
    msgs_etapa_atual:     mudouEtapa ? 1 : (lead.msgs_etapa_atual || 0) + 1,
    total_msgs_fernanda:  (lead.total_msgs_fernanda || 0) + 1,
    total_msgs_mae:       (lead.total_msgs_mae || 0) + 1,
    ultima_mensagem:      new Date().toISOString(),
    pausado:              novaEtapa === 'pausado',
  };

  if (mudouEtapa) {
    campos.etapa_entrada_em = new Date().toISOString();
  }

  return db.atualizarLead(lead.numero, campos);
}

// ============================================================
// PROCESSADOR DE FOLLOW-UP
// ============================================================

/**
 * Processa um follow-up para um lead inativo.
 * Chamado pelo scheduler de followup.js.
 */
async function processarFollowup(lead) {
  log.info({ numero: lead.numero, tentativa: lead.tentativas_followup + 1 }, 'Processando follow-up');

  const tentativa = (lead.tentativas_followup || 0) + 1;

  // Esgotou tentativas → pausa
  if (tentativa > FUNIL.LIMITE_MSGS_POR_ETAPA.followup) {
    await db.atualizarLead(lead.numero, {
      pausado: true,
      etapa:   'pausado',
      atualizado_em: new Date().toISOString(),
    });
    log.info({ numero: lead.numero }, 'Lead pausado após esgotar follow-ups');
    return;
  }

  if (!podeEnviar(lead.numero)) {
    log.warn({ numero: lead.numero }, 'Anti-spam bloqueou follow-up');
    return;
  }

  const contexto    = await db.obterContexto(lead.id);
  const historico   = await db.obterHistorico(lead.id, 6);
  const instrucao   = construirInstrucao('followup', contexto, { tentativa_followup: tentativa });

  const { partes } = await claude.gerarResposta({
    numero:           lead.numero,
    textoUsuario:     '[SISTEMA: envie o follow-up agora, sem mensagem nova da mãe]',
    historico,
    contexto,
    etapa:            'followup',
    instrucaoEtapa:   instrucao,
    systemPrompt:     SYSTEM_BASE,
    historicoFernanda: historico.filter(h => h.role === 'assistant').map(h => h.content),
  });

  await enviarResposta(lead.numero, partes);

  // Salva follow-up no histórico
  const textoFinal = partes.join(' ');
  await db.inserirHistorico(lead.id, 'assistant', textoFinal);

  await db.atualizarLead(lead.numero, {
    tentativas_followup: tentativa,
    etapa:               'followup',
    ultima_mensagem:     new Date().toISOString(),
  });

  await db.registrarEvento(lead.id, 'followup_enviado', { tentativa });
}

// ============================================================
// PROCESSADOR PRINCIPAL — entrada de mensagem
// ============================================================

/**
 * Processa uma mensagem recebida de uma mãe.
 * Ponto de entrada chamado pelo index.js.
 *
 * @param {string} numero  - JID do WhatsApp
 * @param {string} texto   - Mensagem agrupada pelo debounce
 */
async function processarMensagem(numero, texto) {
  log.info({ numero, chars: texto.length }, 'Processando mensagem');

  // ── 1. Carregar lead ──────────────────────────────────────
  let lead;
  try {
    lead = await db.obterOuCriarLead(numero);
  } catch (err) {
    log.error({ numero, err: err.message }, 'Falha ao obter lead — abortando');
    return;
  }

  // Guarda o último texto para detecção de compra na máquina de estados
  lead._ultimo_texto_mae = texto;

  // ── 2. Lead pausado — resposta mínima ────────────────────
  if (lead.pausado || lead.etapa === 'pausado') {
    log.info({ numero }, 'Lead pausado — ignorando mensagem');
    return;
  }

  // ── 3. Salvar mensagem da mãe no histórico ───────────────
  try {
    await db.inserirHistorico(lead.id, 'user', texto);
  } catch (err) {
    log.warn({ numero, err: err.message }, 'Falha ao salvar histórico da mãe');
  }

  // ── 4. Detectar pistas ────────────────────────────────────
  const { contextoAtualizado, analise, onboarding } = await detectarPistas(lead, texto);

  // ── 5. Avaliar progressão dos scores ─────────────────────
  const progressao = avaliarProgressao(lead, analise);

  // ── 6. Decidir nova etapa ─────────────────────────────────
  const { novaEtapa, motivo } = decidirEtapa(lead, analise, progressao, onboarding);

  if (novaEtapa !== lead.etapa) {
    log.info({ numero, de: lead.etapa, para: novaEtapa, motivo }, 'Transição de etapa');
    await db.registrarEvento(lead.id, 'etapa_mudou', { de: lead.etapa, para: novaEtapa, motivo });
  }

  // ── 7. Lead pausado por abandono — sem resposta ───────────
  if (novaEtapa === 'pausado') {
    await db.atualizarLead(numero, {
      etapa:   'pausado',
      pausado: true,
      atualizado_em: new Date().toISOString(),
    });
    log.info({ numero, motivo }, 'Lead pausado');
    return;
  }

  // ── 8. Carregar histórico para o Claude ───────────────────
  let historico = [];
  try {
    historico = await db.obterHistorico(lead.id, 12);
  } catch (err) {
    log.warn({ numero, err: err.message }, 'Falha ao carregar histórico');
  }

  const historicoFernanda = historico
    .filter(h => h.role === 'assistant')
    .map(h => h.content);

  // ── 9. Montar instrução de etapa ──────────────────────────
  const etapaParaResponder = novaEtapa;
  const instrucao = montarInstrucao(etapaParaResponder, contextoAtualizado, analise, lead);

  // ── 10. Gerar resposta via Claude ─────────────────────────
  let partes = [];
  try {
    const resultado = await claude.gerarResposta({
      numero,
      textoUsuario:     texto,
      historico,
      contexto:         contextoAtualizado,
      etapa:            etapaParaResponder,
      instrucaoEtapa:   instrucao,
      systemPrompt:     SYSTEM_BASE,
      historicoFernanda,
    });
    partes = resultado.partes;

    log.info({
      numero,
      etapa:   etapaParaResponder,
      partes:  partes.length,
      tokens:  resultado.tokens,
      latencia: resultado.latencia,
      cached:  resultado.cached,
    }, 'Resposta gerada');

  } catch (err) {
    log.error({ numero, err: err.message }, 'Falha crítica ao gerar resposta');
    return;
  }

  if (!partes || partes.length === 0) {
    log.warn({ numero }, 'Nenhuma parte para enviar');
    return;
  }

  // ── 11. Verificar se deve incluir link ────────────────────
  const incluirLink = deveEnviarLink({
    etapa:          etapaParaResponder,
    podeEnviarLink: podeEnviarLink(numero),
    scoreCompra:    progressao.scoreCompra,
    sinalCompra:    analise.sinal_compra_direta,
  });

  // ── 12. Enviar resposta ───────────────────────────────────
  await enviarResposta(numero, partes, incluirLink);

  // ── 13. Salvar resposta da Fernanda no histórico ──────────
  const textoFinal = partes.join(' ');
  try {
    await db.inserirHistorico(lead.id, 'assistant', textoFinal);
  } catch (err) {
    log.warn({ numero, err: err.message }, 'Falha ao salvar resposta no histórico');
  }

  // ── 14. Persistir estado atualizado ──────────────────────
  try {
    lead = await persistirEstado(lead, novaEtapa, analise, progressao);
  } catch (err) {
    log.error({ numero, err: err.message }, 'Falha ao persistir estado — estado pode estar inconsistente');
  }

  // ── 15. Registrar evento de link se enviou ────────────────
  if (incluirLink) {
    await db.registrarEvento(lead.id, 'link_enviado', {
      etapa:    etapaParaResponder,
      score_compra: progressao.scoreCompra,
    }).catch(err => log.warn({ err: err.message }, 'Falha ao registrar evento link'));
  }

  log.info({ numero, etapa: novaEtapa }, 'Mensagem processada com sucesso');
}

// ============================================================
// INICIALIZAÇÃO
// ============================================================

/**
 * Inicializa o dispatcher e o scheduler de follow-up.
 * Deve ser chamado uma vez no bootstrap (index.js).
 */
function inicializar() {
  // Registra o processador de follow-up no scheduler
  followupScheduler.registrarProcessador(processarFollowup);

  // Inicia o scheduler
  followupScheduler.iniciar();

  log.info('Dispatcher inicializado');
}

// ============================================================
// EXPORTS
// ============================================================

module.exports = {
  processarMensagem,
  processarFollowup,
  inicializar,
};
