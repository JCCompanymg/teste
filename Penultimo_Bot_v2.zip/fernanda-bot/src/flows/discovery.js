'use strict';

// ============================================================
// flows/discovery.js — Etapas: conexao → descoberta → dor
//
// Responsabilidade:
//   - Detectar pistas de dor e interesse no texto
//   - Calcular scores de interesse e emocional
//   - Detectar objeções precoces
//   - Sinalizar quando avançar de etapa
// ============================================================

// ── Scores de palavras-chave de dor ─────────────────────────
const SINAIS_DOR = [
  // tela / tecnologia
  { padrao: /tela|celular|tablet|youtube|ipad|vídeo/i,                     score: 8,  chave: 'dor_tela',        valor: 'excesso de tela' },
  // aprendizado / escola
  { padrao: /n[aã]o (sabe|conhece|reconhece)|trava|dificuldade|atraso/i,   score: 12, chave: 'dor_aprendizado', valor: 'dificuldade de aprendizado' },
  { padrao: /letra|s[íi]laba|ler|leitura|escrever|escrita|alfabeti/i,      score: 10, chave: 'dor_alfabetizacao',valor: 'dificuldade na alfabetização' },
  { padrao: /escola|professor|pedagogo|avalia[çc][aã]o|nota/i,             score: 6,  chave: 'dor_escola',       valor: 'pressão escolar' },
  // emocional
  { padrao: /preocup|ansios|medo|nervos|stress|frustrad/i,                 score: 10, chave: 'dor_emocional',    valor: 'ansiedade com o desenvolvimento' },
  { padrao: /chora|bravo|teimoso|birra|resist[eê]|n[aã]o quer/i,          score: 7,  chave: 'dor_comportamento',valor: 'resistência da criança' },
  // comparação social
  { padrao: /amiguinho|colega|turma|outros|irmão|prima|ja (sabe|l[eê])/i,  score: 9,  chave: 'dor_comparacao',   valor: 'comparação com outras crianças' },
];

// ── Sinais de interesse no produto ──────────────────────────
const SINAIS_INTERESSE = [
  { padrao: /kit|material|produto|comprar|adquir|quanto (custa|vale|é)/i,  score: 15 },
  { padrao: /funciona|resultado|ajud[ao]u|mudou|melhorou/i,               score: 10 },
  { padrao: /como (é|funciona|usa)|me conta|me fala|quero saber/i,        score: 8  },
  { padrao: /interessei|interessante|gostei|parece bom/i,                 score: 12 },
  { padrao: /tem (garantia|devolução)|e se n[aã]o|risco/i,               score: 7  },
  { padrao: /parcel|prazo|boleto|pix|cart[aã]o/i,                        score: 12 },
];

// ── Sinais de objeção ────────────────────────────────────────
const SINAIS_OBJECAO = [
  { padrao: /caro|n[aã]o tenho (dinheiro|grana)|apertado|difícil agora/i,  tipo: 'preco'     },
  { padrao: /n[aã]o (sei|tenho certeza)|preciso pensar|depois|talvez/i,    tipo: 'indecisao' },
  { padrao: /n[aã]o (preciso|quero)|j[aá] tenho|n[aã]o serve/i,          tipo: 'negacao'   },
  { padrao: /meu marido|minha m[aã]e|precisamos ver|a gente v[eê]/i,      tipo: 'terceiro'  },
];

// ── Sinais de abandono ───────────────────────────────────────
const SINAIS_ABANDONO = [
  /n[aã]o (quero|tenho interesse|preciso)/i,
  /obrigad[ao]\s*,?\s*(mas|porém|tchau)/i,
  /n[aã]o é pra mim/i,
  /vou (deixar|passar|parar)/i,
];

// ── Sinais de compra imediata ────────────────────────────────
const SINAIS_COMPRA_DIRETA = [
  /quero (comprar|pagar|adquirir)/i,
  /como (faço|compro|pago|finaliz)/i,
  /me (manda|passa|envie) o link/i,
  /vou (comprar|levar|pegar)/i,
];

/**
 * Analisa o texto e retorna scores e sinais detectados.
 *
 * @param {string} texto        - Mensagem da mãe
 * @param {object} contextoAtu  - Contexto atual do lead (para não re-registrar o que já está lá)
 * @returns {object} resultado da análise
 */
function analisarMensagem(texto, contextoAtual = {}) {
  const resultado = {
    delta_score_interesse: 0,
    delta_score_emocional: 0,
    delta_score_compra:    0,
    novos_contextos:       {}, // { chave: valor } para salvar no banco
    objecoes:              [],
    sinais_abandono:       false,
    sinal_compra_direta:   false,
  };

  // ── Dores ────────────────────────────────────────────────
  for (const sinal of SINAIS_DOR) {
    if (sinal.padrao.test(texto)) {
      resultado.delta_score_emocional += sinal.score;
      resultado.delta_score_interesse += Math.floor(sinal.score * 0.5);

      // Só registra se não estiver no contexto ainda
      if (!contextoAtual[sinal.chave]) {
        resultado.novos_contextos[sinal.chave]  = sinal.valor;
        resultado.novos_contextos.dor_principal = sinal.valor; // sempre atualiza a principal
      }
    }
  }

  // ── Interesse ─────────────────────────────────────────────
  for (const sinal of SINAIS_INTERESSE) {
    if (sinal.padrao.test(texto)) {
      resultado.delta_score_interesse += sinal.score;
      resultado.delta_score_compra    += Math.floor(sinal.score * 0.7);
    }
  }

  // ── Objeções ──────────────────────────────────────────────
  for (const sinal of SINAIS_OBJECAO) {
    if (sinal.padrao.test(texto)) {
      resultado.objecoes.push(sinal.tipo);
      resultado.delta_score_compra -= 5; // objeção reduz score de compra
    }
  }

  // ── Abandono ──────────────────────────────────────────────
  resultado.sinais_abandono = SINAIS_ABANDONO.some(p => p.test(texto));

  // ── Compra direta ─────────────────────────────────────────
  resultado.sinal_compra_direta = SINAIS_COMPRA_DIRETA.some(p => p.test(texto));
  if (resultado.sinal_compra_direta) {
    resultado.delta_score_compra += 25;
  }

  return resultado;
}

/**
 * Decide se a conversa deve avançar para a próxima etapa
 * baseado nos scores acumulados e nos limites de mensagens.
 *
 * Chamado pelo dispatcher — não decide sozinho, apenas aconselha.
 */
function avaliarProgressao(lead, analise) {
  const scoreInteresse = (lead.score_interesse || 0) + analise.delta_score_interesse;
  const scoreEmocional = (lead.score_emocional || 0) + analise.delta_score_emocional;
  const scoreCompra    = (lead.score_compra    || 0) + analise.delta_score_compra;

  return {
    scoreInteresse,
    scoreEmocional,
    scoreCompra,
    deveAnteciparFechamento: scoreCompra >= 60 || analise.sinal_compra_direta,
    prontoPraApresentacao:   scoreInteresse >= 25 && scoreEmocional >= 20,
    prontoPraFechamento:     scoreInteresse >= 45 && scoreCompra >= 20,
    temObjecao:              analise.objecoes.length > 0,
    deveEncerrar:            analise.sinais_abandono,
  };
}

module.exports = {
  analisarMensagem,
  avaliarProgressao,
};
