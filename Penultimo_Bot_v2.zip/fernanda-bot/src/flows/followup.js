'use strict';

// ============================================================
// flows/followup.js — Scheduler de follow-up automático
//
// Responsabilidade:
//   - Verificar leads elegíveis periodicamente
//   - Disparar follow-up nas tentativas corretas
//   - Pausar lead após esgotar tentativas
//   - Cancelar follow-up se lead respondeu
//
// NÃO faz:
//   - Gerar texto (isso é da Fernanda/Claude)
//   - Enviar mensagem diretamente (isso é do whatsapp.js)
//   - Decidir conteúdo do follow-up (isso é do dispatcher)
// ============================================================

const { criarLogger } = require('../services/logger');
const db              = require('../services/database');
const { FOLLOWUP }    = require('../config/constants');

const log = criarLogger({ modulo: 'followup' });

let schedulerAtivo   = false;
let intervaloHandle  = null;

// Callback injetado pelo dispatcher para processar o follow-up
let _processarFollowup = null;

/**
 * Registra o callback que será chamado quando um lead precisar de follow-up.
 * O dispatcher injeta sua própria função aqui durante a inicialização.
 *
 * @param {Function} fn async (lead) => void
 */
function registrarProcessador(fn) {
  _processarFollowup = fn;
}

/**
 * Verifica se um lead é elegível para follow-up.
 * Condições:
 *   - Não pausado
 *   - Etapa não é 'inicio', 'pausado'
 *   - Última mensagem há mais de MINUTOS_INATIVO minutos
 *   - Tentativas abaixo do máximo
 */
function isElegivel(lead) {
  if (lead.pausado) return false;
  if (['inicio', 'pausado'].includes(lead.etapa)) return false;
  if (lead.tentativas_followup >= FOLLOWUP.MAX_TENTATIVAS) return false;

  const ultimaMensagem = new Date(lead.ultima_mensagem).getTime();
  const inativo        = Date.now() - ultimaMensagem;
  const limiteMs       = FOLLOWUP.MINUTOS_INATIVO * 60 * 1000;

  return inativo >= limiteMs;
}

/**
 * Executa um ciclo do scheduler.
 * Busca leads elegíveis e dispara follow-up com delay entre cada um.
 */
async function executarCiclo() {
  log.info('Iniciando ciclo de follow-up');

  let leads;
  try {
    leads = await db.listarLeadsParaFollowup({
      minutosInativo: FOLLOWUP.MINUTOS_INATIVO,
      maxTentativas:  FOLLOWUP.MAX_TENTATIVAS,
    });
  } catch (err) {
    log.error({ err: err.message }, 'Erro ao buscar leads para follow-up');
    return;
  }

  const elegiveis = leads.filter(isElegivel);
  log.info({ total: leads.length, elegiveis: elegiveis.length }, 'Leads avaliados');

  for (const lead of elegiveis) {
    try {
      if (typeof _processarFollowup !== 'function') {
        log.error('Processador de follow-up não registrado — aguardando dispatcher');
        break;
      }

      await _processarFollowup(lead);

      // Delay anti-spam entre leads consecutivos
      await esperar(FOLLOWUP.DELAY_ENTRE_LEADS_MS);

    } catch (err) {
      log.error({ numero: lead.numero, err: err.message }, 'Erro ao processar follow-up do lead');
      // Continua para o próximo lead mesmo em caso de erro
    }
  }

  log.info('Ciclo de follow-up concluído');
}

/**
 * Inicia o scheduler de follow-up.
 * Executa imediatamente e depois em intervalos regulares.
 */
function iniciar() {
  if (schedulerAtivo) {
    log.warn('Scheduler de follow-up já está ativo');
    return;
  }

  schedulerAtivo = true;
  log.info({ intervaloMinutos: FOLLOWUP.INTERVALO_MS / 60000 }, 'Scheduler de follow-up iniciado');

  // Executa primeiro ciclo com delay pequeno (aguarda sistema estabilizar)
  setTimeout(() => {
    executarCiclo().catch(err => log.error({ err: err.message }, 'Erro no primeiro ciclo'));
  }, 10_000);

  // Ciclos subsequentes
  intervaloHandle = setInterval(() => {
    executarCiclo().catch(err => log.error({ err: err.message }, 'Erro no ciclo periódico'));
  }, FOLLOWUP.INTERVALO_MS);
}

/**
 * Para o scheduler (graceful shutdown).
 */
function parar() {
  if (intervaloHandle) {
    clearInterval(intervaloHandle);
    intervaloHandle = null;
  }
  schedulerAtivo = false;
  log.info('Scheduler de follow-up parado');
}

function esperar(ms) {
  return new Promise(r => setTimeout(r, ms));
}

module.exports = {
  iniciar,
  parar,
  registrarProcessador,
  isElegivel,        // exposto para testes
  executarCiclo,     // exposto para testes/admin
};
